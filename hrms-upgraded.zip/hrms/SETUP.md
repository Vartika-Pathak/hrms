# HRFlow HRMS — Wired Frontend + Backend

## What was changed

| File | Change |
|---|---|
| `frontend/Auth.jsx` | Removed hardcoded demo users. Now calls `POST /api/auth/login` and `POST /api/auth/register`. Stores JWT in `localStorage` on success. |
| `frontend/App.jsx` | Removed `useLocalStorage` for user state. Restores session from `localStorage` on mount. Clears token on logout. |
| `frontend/Employees.jsx` | Replaced all `useLocalStorage` with real `employeeAPI` calls. All CRUD (create, read, update, delete) hits the backend. Search/filter sent as query params. |
| `frontend/api.js` | Updated `BASE_URL` to use `import.meta.env.VITE_API_URL` (Vite-compatible). Original used `process.env.REACT_APP_API_URL`. |
| `backend/server.js` | CORS updated to allow both `localhost:3000` (CRA) and `localhost:5173` (Vite). |

---

## Setup Instructions

### 1. Backend

```bash
cd backend

# Copy env file and fill in your values
cp .env.example .env
# Edit .env: set MONGO_URI and JWT_SECRET

npm install
npm run dev   # starts on http://localhost:5000
```

**Seed a user** (first time only — no users exist in a fresh DB):

```bash
# Use the register endpoint:
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Admin User","email":"admin@hrflow.com","password":"admin123","role":"admin"}'
```

### 2. Frontend

```bash
cd frontend

# If using Vite (recommended):
npm install
# Optional: create .env.local with VITE_API_URL=http://localhost:5000/api
npm run dev   # starts on http://localhost:5173

# If using Create React App:
# Rename VITE_API_URL → REACT_APP_API_URL in api.js line 6
# npm start
```

### 3. Login flow

1. Go to `http://localhost:5173`
2. The app shows the Auth screen
3. Register a user OR sign in with an account you seeded
4. On success the backend returns `{ token, user }` — the token is stored in `localStorage` as `hrms_token`
5. Every subsequent API call (including fetching employees) automatically sends `Authorization: Bearer <token>`
6. Employees page fetches real data from MongoDB — no more hardcoded defaults

---

## How the auth wiring works

```
User types email+password → Auth.jsx → authAPI.login() → POST /api/auth/login
  ← { token, user }
  → localStorage.setItem("hrms_token", token)
  → App.jsx sets user state → main app renders

Employees.jsx mounts → employeeAPI.getAll() → GET /api/employees
  → api.js reads token from localStorage, adds Authorization header
  → backend middleware/auth.js verifies JWT → returns employee list
```

---

## Notes

- **EmployeeDetail.jsx** still uses the `employee` prop passed from `Employees.jsx`, so it works without changes — edits/deletes call back through `onUpdate`/`onDelete` which hit the API.
- **Other pages** (Attendance, Payroll, Recruitment, Performance) are unchanged — wire them the same way using the corresponding API exports from `api.js`.
- The backend's `Employee` model uses `_id` (MongoDB ObjectId). The wired `Employees.jsx` uses `emp._id` instead of `emp.id`.
