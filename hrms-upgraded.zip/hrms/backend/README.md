# HRFlow — Backend (Node.js + Express + MongoDB)

## Folder Structure

```
hrms-backend/
├── server.js                  ← Entry point
├── .env.example               ← Copy to .env and fill in values
├── config/
│   └── db.js                  ← MongoDB connection
├── middleware/
│   ├── auth.js                ← JWT protect + adminOnly
│   └── validate.js            ← express-validator error handler
├── models/
│   ├── User.js                ← Auth users
│   ├── Employee.js            ← Employee profiles
│   ├── Attendance.js          ← Daily attendance records
│   ├── Leave.js               ← Leave requests
│   ├── Payroll.js             ← Monthly payslips
│   ├── Job.js                 ← Job postings
│   ├── Candidate.js           ← Job applicants
│   └── Performance.js         ← Review records
├── controllers/               ← Business logic for each module
└── routes/                    ← Express route definitions
```

## Quick Start

### 1. Install dependencies
```bash
cd hrms-backend
npm install
```

### 2. Set up MongoDB Atlas (free)
1. Go to https://cloud.mongodb.com → Create a free cluster
2. Create a database user (username + password)
3. Whitelist your IP address (or allow all: 0.0.0.0/0)
4. Click "Connect" → "Drivers" → copy the connection string

### 3. Create .env
```bash
cp .env.example .env
```
Fill in your values:
```
PORT=5000
MONGO_URI=mongodb+srv://youruser:yourpass@cluster0.mongodb.net/hrms
JWT_SECRET=pick_any_long_random_string
JWT_EXPIRE=7d
NODE_ENV=development
```

### 4. Run the server
```bash
npm run dev      # development (auto-restarts with nodemon)
npm start        # production
```

Server runs at: http://localhost:5000

---

## API Endpoints

### Auth
| Method | Route                       | Description            |
|--------|-----------------------------|------------------------|
| POST   | /api/auth/register          | Register new user      |
| POST   | /api/auth/login             | Login, returns JWT     |
| GET    | /api/auth/me                | Get current user       |
| PUT    | /api/auth/change-password   | Change password        |

### Employees
| Method | Route                          | Description              |
|--------|--------------------------------|--------------------------|
| GET    | /api/employees                 | List all (filter/search) |
| GET    | /api/employees/:id             | Get one employee         |
| POST   | /api/employees                 | Add employee             |
| PUT    | /api/employees/:id             | Update employee          |
| DELETE | /api/employees/:id             | Delete (admin only)      |
| PATCH  | /api/employees/:id/status      | Change status            |
| PATCH  | /api/employees/:id/salary      | Revise salary            |
| GET    | /api/employees/stats/summary   | Dashboard stats          |

### Attendance
| Method | Route                    | Description                   |
|--------|--------------------------|-------------------------------|
| GET    | /api/attendance          | Get records (filter by month) |
| POST   | /api/attendance          | Mark single attendance        |
| POST   | /api/attendance/bulk     | Mark all employees at once    |
| GET    | /api/attendance/summary  | Monthly summary stats         |

### Leaves
| Method | Route                    | Description            |
|--------|--------------------------|------------------------|
| GET    | /api/leaves              | Get all leave requests |
| POST   | /api/leaves              | Apply for leave        |
| PATCH  | /api/leaves/:id/status   | Approve / Reject       |
| DELETE | /api/leaves/:id          | Cancel leave           |

### Payroll
| Method | Route                       | Description                   |
|--------|-----------------------------|-------------------------------|
| GET    | /api/payroll                | Get payroll records           |
| POST   | /api/payroll/generate       | Generate for all employees    |
| POST   | /api/payroll/process-all    | Process all pending           |
| PATCH  | /api/payroll/:id/process    | Process single record         |
| PUT    | /api/payroll/:id            | Update a payroll record       |

### Recruitment
| Method | Route                          | Description              |
|--------|--------------------------------|--------------------------|
| GET    | /api/recruitment/jobs          | List job postings        |
| POST   | /api/recruitment/jobs          | Post a new job           |
| PUT    | /api/recruitment/jobs/:id      | Update job               |
| DELETE | /api/recruitment/jobs/:id      | Delete job               |
| GET    | /api/recruitment/candidates    | List candidates          |
| POST   | /api/recruitment/candidates    | Add candidate            |
| PATCH  | /api/recruitment/candidates/:id| Update stage/score       |
| DELETE | /api/recruitment/candidates/:id| Remove candidate         |

### Performance
| Method | Route                         | Description            |
|--------|-------------------------------|------------------------|
| GET    | /api/performance              | List reviews           |
| POST   | /api/performance              | Create review          |
| PUT    | /api/performance/:id          | Update review          |
| PATCH  | /api/performance/:id/status   | Change review status   |
| GET    | /api/performance/summary      | Summary stats          |

---

## Connecting the React Frontend

1. In `hrms-app/`, create a `.env` file:
```
REACT_APP_API_URL=http://localhost:5000/api
```

2. The file `src/services/api.js` is already set up with all API calls.

3. Replace `useLocalStorage` calls in each page with the corresponding API service. Example for Employees:
```js
// Before (localStorage):
const [employees, setEmployees] = useLocalStorage("hrms_employees", DEFAULT_EMPLOYEES);

// After (API):
import { employeeAPI } from "../services/api";
const [employees, setEmployees] = useState([]);
useEffect(() => { employeeAPI.getAll().then(r => setEmployees(r.employees)); }, []);
```

4. On login, save the token:
```js
const { token, user } = await authAPI.login({ email, password });
localStorage.setItem("hrms_token", token);
```
