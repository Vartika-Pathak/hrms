const jwt      = require("jsonwebtoken");
const User     = require("../models/User");
const Employee = require("../models/Employee");

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || "7d" });

const safeUser = (user) => ({
  id:           user._id,
  name:         user.name,
  email:        user.email,
  role:         user.role,
  employeeId:   user.employeeId,   // null for admin/hr users with no employee record
  leaveBalance: user.leaveBalance,
});

// POST /api/auth/register
exports.register = async (req, res) => {
  try {
    const { name, email, password, role, employeeId } = req.body;
    if (await User.findOne({ email }))
      return res.status(400).json({ error: "Email already registered" });
    // If an employeeId is supplied, validate it exists
    let empRef = null;
    if (employeeId) {
      empRef = await Employee.findById(employeeId);
      if (!empRef) return res.status(400).json({ error: "Employee record not found" });
    }
    const user = await User.create({ name, email, password, role, employeeId: empRef?._id || null });
    res.status(201).json({ token: signToken(user._id), user: safeUser(user) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/auth/login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: "Email and password required" });
    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password)))
      return res.status(401).json({ error: "Invalid email or password" });
    res.json({ token: signToken(user._id), user: safeUser(user) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/auth/me
exports.getMe = async (req, res) => {
  const user = await User.findById(req.user._id);
  res.json({ user: safeUser(user) });
};

// PUT /api/auth/change-password
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id);
    if (!(await user.matchPassword(currentPassword)))
      return res.status(400).json({ error: "Current password is incorrect" });
    user.password = newPassword;
    await user.save();
    res.json({ message: "Password updated successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/auth/leave-balance  — returns current user's leave balance
exports.getLeaveBalance = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("leaveBalance");
    res.json({ leaveBalance: user.leaveBalance });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
