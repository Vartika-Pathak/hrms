const Employee = require("../models/Employee");

// GET /api/employees
exports.getAll = async (req, res) => {
  try {
    const { dept, status, search, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (dept)   filter.dept   = dept;
    if (status) filter.status = status;
    if (search) filter.$or = [
      { name:  { $regex: search, $options: "i" } },
      { email: { $regex: search, $options: "i" } },
      { role:  { $regex: search, $options: "i" } },
    ];
    const total = await Employee.countDocuments(filter);
    const employees = await Employee.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.json({ total, page: Number(page), employees });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/employees/:id
exports.getOne = async (req, res) => {
  try {
    const emp = await Employee.findById(req.params.id);
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/employees
exports.create = async (req, res) => {
  try {
    const emp = await Employee.create(req.body);
    res.status(201).json(emp);
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ error: "Email already exists" });
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/employees/:id
exports.update = async (req, res) => {
  try {
    const emp = await Employee.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE /api/employees/:id
exports.remove = async (req, res) => {
  try {
    const emp = await Employee.findByIdAndDelete(req.params.id);
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json({ message: "Employee deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PATCH /api/employees/:id/status
exports.updateStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const emp = await Employee.findByIdAndUpdate(req.params.id, { status }, { new: true });
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PATCH /api/employees/:id/salary
exports.updateSalary = async (req, res) => {
  try {
    const { salary } = req.body;
    const emp = await Employee.findByIdAndUpdate(req.params.id, { salary }, { new: true });
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/employees/stats/summary
exports.getSummary = async (req, res) => {
  try {
    const total    = await Employee.countDocuments();
    const active   = await Employee.countDocuments({ status: "Active" });
    const onLeave  = await Employee.countDocuments({ status: "On Leave" });
    const inactive = await Employee.countDocuments({ status: "Inactive" });
    const byDept   = await Employee.aggregate([
      { $group: { _id: "$dept", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);
    res.json({ total, active, onLeave, inactive, byDept });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
