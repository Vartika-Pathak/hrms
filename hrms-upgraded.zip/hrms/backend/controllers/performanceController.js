const Performance = require("../models/Performance");

// GET /api/performance — employees see only their own review
exports.getAll = async (req, res) => {
  try {
    const filter = {};
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json([]);
      filter.employee = req.user.employeeId;
    } else {
      const { period, employee, status } = req.query;
      if (period)   filter.period   = period;
      if (employee) filter.employee = employee;
      if (status)   filter.status   = status;
    }
    const reviews = await Performance.find(filter)
      .populate("employee", "name role dept avatar color")
      .populate("reviewedBy", "name")
      .sort({ createdAt: -1 });
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ error: err.message }); }
};

// POST /api/performance — HR/admin only
exports.create = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const review = await Performance.create(req.body);
    await review.populate("employee", "name role dept");
    res.status(201).json(review);
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ error: "Review already exists for this period" });
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/performance/:id — HR/admin/manager
exports.update = async (req, res) => {
  try {
    if (!["admin","hr","manager"].includes(req.user.role))
      return res.status(403).json({ error: "Manager access required" });
    const review = await Performance.findByIdAndUpdate(
      req.params.id,
      { ...req.body, reviewedBy: req.user._id },
      { new: true, runValidators: true }
    ).populate("employee", "name role dept");
    if (!review) return res.status(404).json({ error: "Review not found" });
    res.json(review);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

// PATCH /api/performance/:id/status — HR/admin/manager
exports.updateStatus = async (req, res) => {
  try {
    if (!["admin","hr","manager"].includes(req.user.role))
      return res.status(403).json({ error: "Manager access required" });
    const { status } = req.body;
    const review = await Performance.findByIdAndUpdate(
      req.params.id,
      { status, reviewedBy: req.user._id },
      { new: true }
    ).populate("employee", "name");
    if (!review) return res.status(404).json({ error: "Review not found" });
    res.json(review);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

// GET /api/performance/summary
exports.getSummary = async (req, res) => {
  try {
    const filter = {};
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json({ total: 0, avg: 0, completed: 0, pending: 0 });
      filter.employee = req.user.employeeId;
    } else {
      if (req.query.period) filter.period = req.query.period;
    }
    const reviews = await Performance.find(filter).populate("employee", "name dept");
    const avg = reviews.length ? (reviews.reduce((s, r) => s + r.score, 0) / reviews.length).toFixed(1) : 0;
    const top = [...reviews].sort((a, b) => b.score - a.score)[0];
    res.json({
      total:     reviews.length,
      avg,
      top:       top?.employee?.name || "—",
      completed: reviews.filter(r => r.status === "Completed").length,
      pending:   reviews.filter(r => r.status === "Pending").length,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
};
