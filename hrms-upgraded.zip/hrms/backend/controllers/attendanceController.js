const Attendance = require("../models/Attendance");
const Employee   = require("../models/Employee");

// GET /api/attendance — employees see only their own
exports.getAll = async (req, res) => {
  try {
    const filter = {};
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json([]);
      filter.employee = req.user.employeeId;
    } else {
      const { month, year, employee } = req.query;
      if (employee) filter.employee = employee;
      if (month && year) {
        const start = new Date(year, month - 1, 1);
        const end   = new Date(year, month, 0);
        filter.date = { $gte: start, $lte: end };
      }
    }
    const records = await Attendance.find(filter)
      .populate("employee", "name dept avatar color")
      .sort({ date: -1 });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/attendance  — HR/manager/admin only
exports.mark = async (req, res) => {
  try {
    if (!["admin","hr","manager"].includes(req.user.role))
      return res.status(403).json({ error: "Manager access required to mark attendance" });
    const { employee, date, status, inTime, outTime, remarks } = req.body;
    const record = await Attendance.findOneAndUpdate(
      { employee, date: new Date(date) },
      { status, inTime, outTime, remarks },
      { upsert: true, new: true, runValidators: true }
    );
    res.status(201).json(record);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/attendance/bulk
exports.bulkMark = async (req, res) => {
  try {
    if (!["admin","hr","manager"].includes(req.user.role))
      return res.status(403).json({ error: "Manager access required" });
    const { date, records } = req.body;
    const ops = records.map(r => ({
      updateOne: {
        filter: { employee: r.employee, date: new Date(date) },
        update: { $set: { status: r.status, inTime: r.inTime, outTime: r.outTime } },
        upsert: true,
      },
    }));
    await Attendance.bulkWrite(ops);
    res.json({ message: `Attendance marked for ${records.length} employees` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/attendance/summary — employees get their own summary
exports.getSummary = async (req, res) => {
  try {
    let match = {};
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json([]);
      const { month, year } = req.query;
      if (month && year) {
        const start = new Date(year, month - 1, 1);
        const end   = new Date(year, month, 0);
        match = { employee: req.user.employeeId, date: { $gte: start, $lte: end } };
      } else {
        match = { employee: req.user.employeeId };
      }
    } else {
      const { month, year } = req.query;
      if (month && year) {
        const start = new Date(year, month - 1, 1);
        const end   = new Date(year, month, 0);
        match = { date: { $gte: start, $lte: end } };
      }
    }
    const summary = await Attendance.aggregate([
      { $match: match },
      { $group: { _id: "$status", count: { $sum: 1 } } },
    ]);
    res.json(summary);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
