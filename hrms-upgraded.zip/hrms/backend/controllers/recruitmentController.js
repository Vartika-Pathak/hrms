const Job       = require("../models/Job");
const Candidate = require("../models/Candidate");

// ── Jobs ──────────────────────────────────────────────
exports.getJobs = async (_req, res) => {
  try {
    const jobs = await Job.find().populate("postedBy","name").sort({ createdAt: -1 });
    res.json(jobs);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.createJob = async (req, res) => {
  try {
    const job = await Job.create({ ...req.body, postedBy: req.user._id });
    res.status(201).json(job);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.updateJob = async (req, res) => {
  try {
    const job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!job) return res.status(404).json({ error: "Job not found" });
    res.json(job);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.deleteJob = async (req, res) => {
  try {
    await Job.findByIdAndDelete(req.params.id);
    res.json({ message: "Job deleted" });
  } catch (err) { res.status(500).json({ error: err.message }); }
};

// ── Candidates ────────────────────────────────────────
exports.getCandidates = async (req, res) => {
  try {
    const { job, stage } = req.query;
    const filter = {};
    if (job)   filter.job   = job;
    if (stage) filter.stage = stage;
    const candidates = await Candidate.find(filter).populate("job","title dept").sort({ createdAt: -1 });
    res.json(candidates);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.addCandidate = async (req, res) => {
  try {
    const candidate = await Candidate.create(req.body);
    await candidate.populate("job","title dept");
    // Increment applicant count on the job
    await Job.findByIdAndUpdate(req.body.job, { $inc: { openings: 0 } }); // placeholder — track separately if needed
    res.status(201).json(candidate);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.updateCandidateStage = async (req, res) => {
  try {
    const { stage, score, notes } = req.body;
    const candidate = await Candidate.findByIdAndUpdate(
      req.params.id, { stage, score, notes }, { new: true }
    ).populate("job","title");
    if (!candidate) return res.status(404).json({ error: "Candidate not found" });
    res.json(candidate);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.deleteCandidate = async (req, res) => {
  try {
    await Candidate.findByIdAndDelete(req.params.id);
    res.json({ message: "Candidate removed" });
  } catch (err) { res.status(500).json({ error: err.message }); }
};
