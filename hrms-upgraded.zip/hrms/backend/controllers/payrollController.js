const Payroll  = require("../models/Payroll");
const Employee = require("../models/Employee");

// GET /api/payroll — employees see only their own
exports.getAll = async (req, res) => {
  try {
    const filter = {};
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json([]);
      filter.employee = req.user.employeeId;
    } else {
      const { month, year, employee } = req.query;
      if (month)    filter.month    = month;
      if (year)     filter.year     = Number(year);
      if (employee) filter.employee = employee;
    }
    const records = await Payroll.find(filter)
      .populate("employee", "name dept avatar color salary")
      .sort({ createdAt: -1 });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/payroll/generate  — HR/admin only
exports.generate = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const { month, year } = req.body;
    const employees = await Employee.find({ status: "Active" });
    const created = [];
    for (const emp of employees) {
      const basic      = emp.salary;
      const hra        = Math.round(basic * 0.2);
      const ta         = 5000;
      const deductions = Math.round(basic * 0.1);
      const tax        = Math.round(basic * 0.05);
      try {
        const record = await Payroll.create({ employee: emp._id, month, year, basic, hra, ta, deductions, tax });
        created.push(record);
      } catch (e) {
        if (e.code !== 11000) throw e;
      }
    }
    res.status(201).json({ message: `Generated payroll for ${created.length} employees`, created });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PATCH /api/payroll/:id/process  — HR/admin only
exports.process = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const record = await Payroll.findByIdAndUpdate(
      req.params.id,
      { status: "Processed", processedBy: req.user._id, processedAt: new Date() },
      { new: true }
    ).populate("employee", "name dept");
    if (!record) return res.status(404).json({ error: "Payroll record not found" });
    res.json(record);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/payroll/process-all  — HR/admin only
exports.processAll = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const { month, year } = req.body;
    const result = await Payroll.updateMany(
      { month, year, status: "Pending" },
      { status: "Processed", processedBy: req.user._id, processedAt: new Date() }
    );
    res.json({ message: `Processed ${result.modifiedCount} payroll records` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/payroll/:id  — HR/admin only
exports.update = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const record = await Payroll.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!record) return res.status(404).json({ error: "Payroll record not found" });
    res.json(record);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
