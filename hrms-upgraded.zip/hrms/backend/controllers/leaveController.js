const Leave    = require("../models/Leave");
const Employee = require("../models/Employee");
const User     = require("../models/User");

// ── Helpers ──────────────────────────────────────────────────────────
const isHROrAdmin   = (u) => ["admin","hr"].includes(u.role);
const isManagerUp   = (u) => ["admin","hr","manager"].includes(u.role);

// Deduct or restore leave balance on the employee's linked User account
const adjustBalance = async (employeeObjectId, leaveType, days, op) => {
  // op = "deduct" | "restore" | "pend" | "unpend"
  const user = await User.findOne({ employeeId: employeeObjectId });
  if (!user) return;
  const bal = user.leaveBalance.find(b => b.type === leaveType);
  if (!bal) return;

  if (op === "pend")    bal.pending = (bal.pending || 0) + days;
  if (op === "unpend")  bal.pending = Math.max(0, (bal.pending || 0) - days);
  if (op === "deduct") {
    bal.used    = (bal.used || 0) + days;
    bal.pending = Math.max(0, (bal.pending || 0) - days);
  }
  if (op === "restore") {
    bal.used    = Math.max(0, (bal.used || 0) - days);
  }
  await user.save();
};

// GET /api/leaves
exports.getAll = async (req, res) => {
  try {
    const filter = {};
    // Employees only see their own leaves
    if (req.user.role === "employee") {
      if (!req.user.employeeId)
        return res.json([]);  // no linked employee record yet
      filter.employee = req.user.employeeId;
    } else {
      // HR/admin/manager may filter
      const { employee, status } = req.query;
      if (employee) filter.employee = employee;
      if (status)   filter.status   = status;
    }
    const leaves = await Leave.find(filter)
      .populate("employee", "name dept avatar color")
      .populate("approvedBy", "name")
      .sort({ createdAt: -1 });
    res.json(leaves);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/leaves
exports.apply = async (req, res) => {
  try {
    let { employee, type, from, to, reason } = req.body;

    // Employees can only apply for themselves
    if (req.user.role === "employee") {
      if (!req.user.employeeId)
        return res.status(400).json({ error: "No employee profile linked to your account" });
      employee = req.user.employeeId;
    }

    const fromDate = new Date(from);
    const toDate   = new Date(to);
    const days     = Math.ceil((toDate - fromDate) / 86400000) + 1;

    // Check available balance (for employee role)
    if (req.user.role === "employee") {
      const user = await User.findById(req.user._id).select("leaveBalance");
      const bal  = user?.leaveBalance?.find(b => b.type === type);
      if (bal) {
        const available = bal.total - bal.used - (bal.pending || 0);
        if (days > available)
          return res.status(400).json({
            error: `Insufficient ${type} balance. Available: ${available} days, requested: ${days} days`,
          });
      }
    }

    const leave = await Leave.create({ employee, type, from: fromDate, to: toDate, days, reason });
    await leave.populate("employee", "name dept");

    // Mark as pending in balance
    await adjustBalance(employee, type, days, "pend");

    res.status(201).json(leave);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PATCH /api/leaves/:id/status  — HR/manager only
exports.updateStatus = async (req, res) => {
  try {
    if (!isManagerUp(req.user))
      return res.status(403).json({ error: "Manager access required to approve/reject leaves" });

    const { status, remarks } = req.body;
    const prevLeave = await Leave.findById(req.params.id);
    if (!prevLeave) return res.status(404).json({ error: "Leave not found" });

    const leave = await Leave.findByIdAndUpdate(
      req.params.id,
      { status, remarks, approvedBy: req.user._id },
      { new: true }
    ).populate("employee", "name dept");

    // Balance adjustments
    if (status === "Approved" && prevLeave.status !== "Approved") {
      // Deduct from used, remove pending
      await adjustBalance(prevLeave.employee, prevLeave.type, prevLeave.days, "deduct");
      await Employee.findByIdAndUpdate(prevLeave.employee, { status: "On Leave" });
    } else if (status === "Rejected" && prevLeave.status === "Pending") {
      // Restore the pending hold
      await adjustBalance(prevLeave.employee, prevLeave.type, prevLeave.days, "unpend");
    } else if (status === "Rejected" && prevLeave.status === "Approved") {
      // Was approved before — restore used
      await adjustBalance(prevLeave.employee, prevLeave.type, prevLeave.days, "restore");
    }

    res.json(leave);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE /api/leaves/:id  — cancel (employee cancels their own; HR can cancel any)
exports.cancel = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) return res.status(404).json({ error: "Leave not found" });

    // Employees can only cancel their own
    if (req.user.role === "employee") {
      if (!req.user.employeeId || leave.employee.toString() !== req.user.employeeId.toString())
        return res.status(403).json({ error: "You can only cancel your own leaves" });
      if (leave.status === "Approved")
        return res.status(400).json({ error: "Cannot cancel an approved leave. Contact HR." });
    }

    // Restore balance if was pending or approved
    if (leave.status === "Pending")  await adjustBalance(leave.employee, leave.type, leave.days, "unpend");
    if (leave.status === "Approved") await adjustBalance(leave.employee, leave.type, leave.days, "restore");

    await Leave.findByIdAndDelete(req.params.id);
    res.json({ message: "Leave cancelled" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
