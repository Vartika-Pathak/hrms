/**
 * api.js — Central Axios instance for all HRMS API calls.
 * Automatically attaches JWT token to every request.
 * Import individual service modules from this file.
 */

const BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

// ── Helper: build headers ────────────────────────────────────────────
const headers = () => {
  const token = localStorage.getItem("hrms_token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

// ── Core fetch wrapper ───────────────────────────────────────────────
const request = async (method, path, body = null) => {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: headers(),
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
};

const get    = (path)        => request("GET",    path);
const post   = (path, body)  => request("POST",   path, body);
const put    = (path, body)  => request("PUT",    path, body);
const patch  = (path, body)  => request("PATCH",  path, body);
const del    = (path)        => request("DELETE", path);

// ── Auth ─────────────────────────────────────────────────────────────
export const authAPI = {
  login:          (body) => post("/auth/login", body),
  register:       (body) => post("/auth/register", body),
  me:             ()     => get("/auth/me"),
  changePassword: (body) => put("/auth/change-password", body),
};

// ── Employees ────────────────────────────────────────────────────────
export const employeeAPI = {
  getAll:       (params = {}) => get(`/employees?${new URLSearchParams(params)}`),
  getOne:       (id)          => get(`/employees/${id}`),
  create:       (body)        => post("/employees", body),
  update:       (id, body)    => put(`/employees/${id}`, body),
  remove:       (id)          => del(`/employees/${id}`),
  updateStatus: (id, status)  => patch(`/employees/${id}/status`, { status }),
  updateSalary: (id, salary)  => patch(`/employees/${id}/salary`, { salary }),
  getSummary:   ()            => get("/employees/stats/summary"),
};

// ── Attendance ───────────────────────────────────────────────────────
export const attendanceAPI = {
  getAll:    (params = {}) => get(`/attendance?${new URLSearchParams(params)}`),
  getSummary:(params = {}) => get(`/attendance/summary?${new URLSearchParams(params)}`),
  mark:      (body)        => post("/attendance", body),
  bulkMark:  (body)        => post("/attendance/bulk", body),
};

// ── Leaves ───────────────────────────────────────────────────────────
export const leaveAPI = {
  getAll:       (params = {}) => get(`/leaves?${new URLSearchParams(params)}`),
  apply:        (body)        => post("/leaves", body),
  updateStatus: (id, status, remarks) => patch(`/leaves/${id}/status`, { status, remarks }),
  cancel:       (id)          => del(`/leaves/${id}`),
};

// ── Payroll ──────────────────────────────────────────────────────────
export const payrollAPI = {
  getAll:      (params = {}) => get(`/payroll?${new URLSearchParams(params)}`),
  generate:    (body)        => post("/payroll/generate", body),
  processAll:  (body)        => post("/payroll/process-all", body),
  process:     (id)          => patch(`/payroll/${id}/process`),
  update:      (id, body)    => put(`/payroll/${id}`, body),
};

// ── Recruitment ──────────────────────────────────────────────────────
export const recruitmentAPI = {
  getJobs:              ()      => get("/recruitment/jobs"),
  createJob:            (body)  => post("/recruitment/jobs", body),
  updateJob:            (id, b) => put(`/recruitment/jobs/${id}`, b),
  deleteJob:            (id)    => del(`/recruitment/jobs/${id}`),
  getCandidates:        (p={})  => get(`/recruitment/candidates?${new URLSearchParams(p)}`),
  addCandidate:         (body)  => post("/recruitment/candidates", body),
  updateCandidateStage: (id, b) => patch(`/recruitment/candidates/${id}`, b),
  deleteCandidate:      (id)    => del(`/recruitment/candidates/${id}`),
};

// ── Performance ──────────────────────────────────────────────────────
export const performanceAPI = {
  getAll:       (params = {}) => get(`/performance?${new URLSearchParams(params)}`),
  getSummary:   (params = {}) => get(`/performance/summary?${new URLSearchParams(params)}`),
  create:       (body)        => post("/performance", body),
  update:       (id, body)    => put(`/performance/${id}`, body),
  updateStatus: (id, status)  => patch(`/performance/${id}/status`, { status }),
};
