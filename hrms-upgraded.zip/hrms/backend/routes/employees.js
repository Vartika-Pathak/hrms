const router = require("express").Router();
const ctrl   = require("../controllers/employeeController");
const { protect, adminOnly } = require("../middleware/auth");

router.use(protect);

router.get("/stats/summary", ctrl.getSummary);
router.get("/",              ctrl.getAll);
router.get("/:id",           ctrl.getOne);
router.post("/",             ctrl.create);
router.put("/:id",           ctrl.update);
router.delete("/:id",        adminOnly, ctrl.remove);
router.patch("/:id/status",  ctrl.updateStatus);
router.patch("/:id/salary",  ctrl.updateSalary);

module.exports = router;
