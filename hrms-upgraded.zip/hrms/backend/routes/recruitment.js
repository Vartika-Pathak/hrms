const router = require("express").Router();
const ctrl   = require("../controllers/recruitmentController");
const { protect } = require("../middleware/auth");

router.use(protect);

// Jobs
router.get("/jobs",          ctrl.getJobs);
router.post("/jobs",         ctrl.createJob);
router.put("/jobs/:id",      ctrl.updateJob);
router.delete("/jobs/:id",   ctrl.deleteJob);

// Candidates
router.get("/candidates",           ctrl.getCandidates);
router.post("/candidates",          ctrl.addCandidate);
router.patch("/candidates/:id",     ctrl.updateCandidateStage);
router.delete("/candidates/:id",    ctrl.deleteCandidate);

module.exports = router;
