const router = require("express").Router();
const ctrl   = require("../controllers/payrollController");
const { protect } = require("../middleware/auth");

router.use(protect);

router.get("/",               ctrl.getAll);
router.post("/generate",      ctrl.generate);
router.post("/process-all",   ctrl.processAll);
router.patch("/:id/process",  ctrl.process);
router.put("/:id",            ctrl.update);

module.exports = router;
