const router = require("express").Router();
const ctrl   = require("../controllers/attendanceController");
const { protect } = require("../middleware/auth");

router.use(protect);

router.get("/",          ctrl.getAll);
router.get("/summary",   ctrl.getSummary);
router.post("/",         ctrl.mark);
router.post("/bulk",     ctrl.bulkMark);

module.exports = router;
