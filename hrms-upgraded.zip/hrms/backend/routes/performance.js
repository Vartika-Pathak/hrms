const router = require("express").Router();
const ctrl   = require("../controllers/performanceController");
const { protect } = require("../middleware/auth");

router.use(protect);

router.get("/summary",        ctrl.getSummary);
router.get("/",               ctrl.getAll);
router.post("/",              ctrl.create);
router.put("/:id",            ctrl.update);
router.patch("/:id/status",   ctrl.updateStatus);

module.exports = router;
