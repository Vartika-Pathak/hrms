const router = require("express").Router();
const ctrl   = require("../controllers/leaveController");
const { protect } = require("../middleware/auth");

router.use(protect);

router.get("/",                   ctrl.getAll);
router.post("/",                  ctrl.apply);
router.patch("/:id/status",       ctrl.updateStatus);
router.delete("/:id",             ctrl.cancel);

module.exports = router;
