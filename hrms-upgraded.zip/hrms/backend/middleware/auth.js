const jwt  = require("jsonwebtoken");
const User = require("../models/User");

const protect = async (req, res, next) => {
  let token;
  if (req.headers.authorization?.startsWith("Bearer "))
    token = req.headers.authorization.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Not authorized — no token" });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select("-password");
    if (!req.user) return res.status(401).json({ error: "User not found" });
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
};

// Admin or HR can do anything; managers see their team; employees see only themselves
const adminOnly = (req, res, next) => {
  if (!["admin", "hr"].includes(req.user?.role))
    return res.status(403).json({ error: "HR/Admin access required" });
  next();
};

const managerOrAbove = (req, res, next) => {
  if (!["admin", "hr", "manager"].includes(req.user?.role))
    return res.status(403).json({ error: "Manager access required" });
  next();
};

module.exports = { protect, adminOnly, managerOrAbove };
