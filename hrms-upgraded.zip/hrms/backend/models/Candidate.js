const mongoose = require("mongoose");

const candidateSchema = new mongoose.Schema({
  name:    { type: String, required: true },
  email:   { type: String, required: true },
  phone:   { type: String },
  job:     { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
  resume:  { type: String },   // URL or file path
  score:   { type: Number, default: 0 },
  stage:   {
    type: String,
    enum: ["Applied","Screening","Technical Interview","HR Round","Offer","Hired","Rejected"],
    default: "Applied",
  },
  notes:   { type: String },
}, { timestamps: true });

module.exports = mongoose.model("Candidate", candidateSchema);
