const mongoose = require("mongoose");
const bcrypt   = require("bcryptjs");

const leaveBalanceSchema = new mongoose.Schema({
  type:    { type: String },
  total:   { type: Number, default: 0 },
  used:    { type: Number, default: 0 },
  pending: { type: Number, default: 0 },
}, { _id: false });

const userSchema = new mongoose.Schema({
  name:       { type: String, required: true, trim: true },
  email:      { type: String, required: true, unique: true, lowercase: true },
  password:   { type: String, required: true, minlength: 6 },
  role:       { type: String, enum: ["admin", "hr", "manager", "employee"], default: "hr" },
  // Link to the Employee record so employees only see their own data
  employeeId: { type: mongoose.Schema.Types.ObjectId, ref: "Employee", default: null },
  // Leave balance tracked per user (primarily for role=employee)
  leaveBalance: {
    type: [leaveBalanceSchema],
    default: [
      { type: "Sick Leave",      total: 12, used: 0, pending: 0 },
      { type: "Casual Leave",    total: 12, used: 0, pending: 0 },
      { type: "Earned Leave",    total: 15, used: 0, pending: 0 },
      { type: "WFH",             total: 24, used: 0, pending: 0 },
      { type: "Maternity Leave", total: 26, used: 0, pending: 0 },
      { type: "Paternity Leave", total: 5,  used: 0, pending: 0 },
    ],
  },
}, { timestamps: true });

userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.matchPassword = async function (entered) {
  return bcrypt.compare(entered, this.password);
};

module.exports = mongoose.model("User", userSchema);
