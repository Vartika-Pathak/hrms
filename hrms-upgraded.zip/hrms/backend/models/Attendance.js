const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema({
  employee:  { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
  date:      { type: Date, required: true },
  status:    { type: String, enum: ["Present","Absent","Leave","WFH","Holiday"], default: "Present" },
  inTime:    { type: String },
  outTime:   { type: String },
  remarks:   { type: String },
}, { timestamps: true });

// One record per employee per day
attendanceSchema.index({ employee: 1, date: 1 }, { unique: true });

module.exports = mongoose.model("Attendance", attendanceSchema);
