const mongoose = require("mongoose");

const payrollSchema = new mongoose.Schema({
  employee:   { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
  month:      { type: String, required: true },   // e.g. "May 2025"
  year:       { type: Number, required: true },
  basic:      { type: Number, required: true },
  hra:        { type: Number, default: 0 },
  ta:         { type: Number, default: 0 },
  bonus:      { type: Number, default: 0 },
  deductions: { type: Number, default: 0 },
  tax:        { type: Number, default: 0 },
  netPay:     { type: Number },                   // auto-computed
  status:     { type: String, enum: ["Pending","Processed","On Hold"], default: "Pending" },
  processedBy:{ type: mongoose.Schema.Types.ObjectId, ref: "User" },
  processedAt:{ type: Date },
}, { timestamps: true });

// Auto-compute netPay before save
payrollSchema.pre("save", function (next) {
  this.netPay = this.basic + this.hra + this.ta + this.bonus - this.deductions - this.tax;
  next();
});

// One payroll per employee per month/year
payrollSchema.index({ employee: 1, month: 1, year: 1 }, { unique: true });

module.exports = mongoose.model("Payroll", payrollSchema);
