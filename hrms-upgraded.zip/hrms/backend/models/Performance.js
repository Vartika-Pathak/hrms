const mongoose = require("mongoose");

const skillSchema = new mongoose.Schema({
  name:  { type: String },
  score: { type: Number, min: 0, max: 100 },
}, { _id: false });

const performanceSchema = new mongoose.Schema({
  employee:  { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
  period:    { type: String, required: true },    // e.g. "Q1 2025"
  score:     { type: Number, min: 0, max: 100 },
  rating:    { type: String, enum: ["Average","Good","Very Good","Excellent","Outstanding"] },
  goals:     { type: Number, default: 0 },
  goalsmet:  { type: Number, default: 0 },
  skills:    [skillSchema],
  feedback:  { type: String },
  status:    { type: String, enum: ["Pending","In Review","Completed"], default: "Pending" },
  reviewedBy:{ type: mongoose.Schema.Types.ObjectId, ref: "User" },
}, { timestamps: true });

performanceSchema.index({ employee: 1, period: 1 }, { unique: true });

module.exports = mongoose.model("Performance", performanceSchema);
