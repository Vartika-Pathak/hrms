const mongoose = require("mongoose");

const leaveSchema = new mongoose.Schema({
  employee:   { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
  type:       { type: String, enum: ["Sick Leave","Casual Leave","Earned Leave","WFH","Maternity Leave","Paternity Leave"], required: true },
  from:       { type: Date, required: true },
  to:         { type: Date, required: true },
  days:       { type: Number, required: true },
  reason:     { type: String, required: true },
  status:     { type: String, enum: ["Pending","Approved","Rejected"], default: "Pending" },
  approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  remarks:    { type: String },
}, { timestamps: true });

module.exports = mongoose.model("Leave", leaveSchema);
