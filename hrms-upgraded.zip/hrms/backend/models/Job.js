const mongoose = require("mongoose");

const jobSchema = new mongoose.Schema({
  title:       { type: String, required: true },
  dept:        { type: String, required: true },
  type:        { type: String, enum: ["Full-Time","Part-Time","Contract","Internship"], default: "Full-Time" },
  openings:    { type: Number, default: 1 },
  description: { type: String },
  requirements:{ type: String },
  status:      { type: String, enum: ["Active","Paused","Closed"], default: "Active" },
  postedBy:    { type: mongoose.Schema.Types.ObjectId, ref: "User" },
}, { timestamps: true });

module.exports = mongoose.model("Job", jobSchema);
