const mongoose = require("mongoose");

const employeeSchema = new mongoose.Schema({
  employeeId:  { type: String, unique: true },   // auto-generated e.g. EMP-0001
  name:        { type: String, required: true, trim: true },
  role:        { type: String, required: true },
  dept:        { type: String, required: true },
  email:       { type: String, required: true, unique: true, lowercase: true },
  phone:       { type: String },
  status:      { type: String, enum: ["Active","On Leave","Inactive"], default: "Active" },
  joined:      { type: Date },
  salary:      { type: Number, default: 0 },
  manager:     { type: String },
  address:     { type: String },
  dob:         { type: Date },
  gender:      { type: String, enum: ["Male","Female","Other"] },
  blood:       { type: String },
  emergency:   { type: String },
  pan:         { type: String },
  bank:        { type: String },
  notes:       { type: String },
  avatar:      { type: String },   // initials
  color:       { type: String },   // hex color
}, { timestamps: true });

// Auto-generate employeeId before save
employeeSchema.pre("save", async function (next) {
  if (this.isNew && !this.employeeId) {
    const count = await mongoose.model("Employee").countDocuments();
    this.employeeId = `EMP-${String(count + 1).padStart(4, "0")}`;
  }
  // Auto-generate avatar initials
  if (this.isModified("name") || !this.avatar) {
    this.avatar = this.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  }
  next();
});

module.exports = mongoose.model("Employee", employeeSchema);
