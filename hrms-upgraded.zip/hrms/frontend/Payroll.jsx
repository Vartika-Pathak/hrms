import { useState, useEffect, useCallback } from "react";
import { payrollAPI } from "./api";

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export default function Payroll({ user }) {
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(MONTHS[now.getMonth()]);
  const [selectedYear,  setSelectedYear]  = useState(now.getFullYear());
  const [payroll,  setPayroll]  = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState("");
  const [saving,   setSaving]   = useState(false);
  const [tab,      setTab]      = useState("summary");

  const isEmployee = user?.role === "employee";
  const canManage  = ["admin","hr"].includes(user?.role);

  const fetchPayroll = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const data = await payrollAPI.getAll({ month: `${selectedMonth} ${selectedYear}`, year: selectedYear });
      setPayroll(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [selectedMonth, selectedYear]);

  useEffect(() => { fetchPayroll(); }, [fetchPayroll]);

  const getNet = (e) => (e.netPay ?? (e.basic + e.hra + e.ta + (e.bonus||0) - e.deductions - (e.tax||0)));
  const total  = (fn) => payroll.reduce((s,e) => s + fn(e), 0);

  const generate = async () => {
    setSaving(true);
    try {
      await payrollAPI.generate({ month: `${selectedMonth} ${selectedYear}`, year: selectedYear });
      fetchPayroll();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const process = async (id) => {
    setSaving(true);
    try {
      await payrollAPI.process(id);
      fetchPayroll();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const processAll = async () => {
    setSaving(true);
    try {
      await payrollAPI.processAll({ month: `${selectedMonth} ${selectedYear}`, year: selectedYear });
      fetchPayroll();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Payroll</h1>
          <p className="page-subtitle">
            {isEmployee ? "Your salary information" : "Manage and process employee salaries"}
          </p>
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <select className="select" style={{ width:"auto" }} value={selectedMonth} onChange={e=>setSelectedMonth(e.target.value)}>
            {MONTHS.map(m=><option key={m}>{m}</option>)}
          </select>
          <select className="select" style={{ width:"auto" }} value={selectedYear} onChange={e=>setSelectedYear(Number(e.target.value))}>
            {[2024,2025,2026].map(y=><option key={y}>{y}</option>)}
          </select>
          {canManage && (
            <>
              <button className="btn btn-ghost"    onClick={generate}    disabled={saving}>⚙ Generate</button>
              <button className="btn btn-primary"  onClick={processAll}  disabled={saving}>▶ Run Payroll</button>
            </>
          )}
        </div>
      </div>

      {!isEmployee && (
        <div className="stat-grid">
          {[
            { label:"Total Gross",     value:`₹${(total(e=>e.basic+e.hra+e.ta+(e.bonus||0))/100000).toFixed(1)}L`, icon:"💵", color:"blue"   },
            { label:"Total Deductions",value:`₹${(total(e=>e.deductions+(e.tax||0))/1000).toFixed(0)}K`,           icon:"📉", color:"red"    },
            { label:"Net Payable",     value:`₹${(total(getNet)/100000).toFixed(1)}L`,                              icon:"✅", color:"green"  },
            { label:"Processed",       value:`${payroll.filter(e=>e.status==="Processed").length}/${payroll.length}`, icon:"📋", color:"yellow" },
          ].map(s=>(
            <div className={`stat-card ${s.color}`} key={s.label}>
              <div className="stat-icon" style={{ background:"var(--bg-hover)" }}>{s.icon}</div>
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {error && <div className="auth-error" style={{ marginBottom:16 }}>{error}</div>}

      <div className="tabs">
        <button className={`tab ${tab==="summary"?"active":""}`}   onClick={()=>setTab("summary")}>Salary Summary</button>
        <button className={`tab ${tab==="breakdown"?"active":""}`} onClick={()=>setTab("breakdown")}>Breakdown</button>
      </div>

      {loading ? (
        <div className="card" style={{ textAlign:"center", padding:60, color:"var(--text-muted)" }}>Loading payroll…</div>
      ) : payroll.length === 0 ? (
        <div className="card" style={{ textAlign:"center", padding:60, color:"var(--text-muted)" }}>
          No payroll data for {selectedMonth} {selectedYear}.
          {canManage && <span> Click <strong>⚙ Generate</strong> to create it.</span>}
        </div>
      ) : tab==="summary" ? (
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Employee</th>
                  {!isEmployee && <th>Department</th>}
                  <th>Basic</th><th>HRA</th><th>TA</th>
                  <th>Deductions</th>
                  {!isEmployee && <th>Tax</th>}
                  <th>Net Pay</th><th>Status</th>
                  {canManage && <th>Action</th>}
                </tr>
              </thead>
              <tbody>
                {payroll.map(emp=>(
                  <tr key={emp._id}>
                    <td>
                      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                        <div className="avatar" style={{ background:(emp.employee?.color||"#4f8bff")+"22", color:emp.employee?.color||"#4f8bff" }}>
                          {emp.employee?.avatar}
                        </div>
                        <span style={{ fontWeight:600 }}>{emp.employee?.name}</span>
                      </div>
                    </td>
                    {!isEmployee && <td><span className="badge badge-blue">{emp.employee?.dept}</span></td>}
                    <td>₹{emp.basic?.toLocaleString()}</td>
                    <td>₹{emp.hra?.toLocaleString()}</td>
                    <td>₹{emp.ta?.toLocaleString()}</td>
                    <td style={{ color:"var(--accent-3)" }}>-₹{emp.deductions?.toLocaleString()}</td>
                    {!isEmployee && <td style={{ color:"var(--accent-3)" }}>-₹{emp.tax?.toLocaleString()}</td>}
                    <td style={{ fontWeight:700, color:"var(--accent-2)" }}>₹{getNet(emp).toLocaleString()}</td>
                    <td>
                      {emp.status==="Processed" && <span className="badge badge-green">Processed</span>}
                      {emp.status==="Pending"   && <span className="badge badge-yellow">Pending</span>}
                      {emp.status==="On Hold"   && <span className="badge badge-red">On Hold</span>}
                    </td>
                    {canManage && (
                      <td>
                        {emp.status!=="Processed"
                          ? <button className="btn btn-success" style={{ padding:"5px 10px", fontSize:12 }} onClick={()=>process(emp._id)} disabled={saving}>Process</button>
                          : <span style={{ fontSize:12, color:"var(--text-muted)" }}>✓ Done</span>
                        }
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20 }}>
          {payroll.map(emp=>(
            <div className="card" key={emp._id}>
              <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:20 }}>
                <div className="avatar" style={{ background:(emp.employee?.color||"#4f8bff")+"22", color:emp.employee?.color||"#4f8bff", width:44, height:44, fontSize:16 }}>
                  {emp.employee?.avatar}
                </div>
                <div>
                  <div style={{ fontWeight:700 }}>{emp.employee?.name}</div>
                  <div style={{ fontSize:12, color:"var(--text-secondary)" }}>{emp.employee?.dept}</div>
                </div>
                <div style={{ marginLeft:"auto" }}>
                  {emp.status==="Processed" && <span className="badge badge-green">Processed</span>}
                  {emp.status==="Pending"   && <span className="badge badge-yellow">Pending</span>}
                  {emp.status==="On Hold"   && <span className="badge badge-red">On Hold</span>}
                </div>
              </div>
              {[
                { label:"Basic Salary",     value: emp.basic,           color:"var(--text-primary)" },
                { label:"HRA",              value: emp.hra,             color:"var(--text-primary)" },
                { label:"Travel Allowance", value: emp.ta,              color:"var(--text-primary)" },
                { label:"Bonus",            value: emp.bonus||0,        color:"var(--accent-2)"     },
                { label:"Deductions",       value:-emp.deductions,      color:"var(--accent-3)"     },
                { label:"Tax",              value:-(emp.tax||0),        color:"var(--accent-3)"     },
              ].map(row=>(
                <div key={row.label} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid var(--border)", fontSize:13 }}>
                  <span style={{ color:"var(--text-secondary)" }}>{row.label}</span>
                  <span style={{ color:row.color, fontWeight:600 }}>
                    {row.value<0?`-₹${Math.abs(row.value).toLocaleString()}`:`₹${row.value.toLocaleString()}`}
                  </span>
                </div>
              ))}
              <div style={{ display:"flex", justifyContent:"space-between", padding:"12px 0 0", fontWeight:700, fontSize:15 }}>
                <span>Net Pay</span>
                <span style={{ color:"var(--accent-2)" }}>₹{getNet(emp).toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
