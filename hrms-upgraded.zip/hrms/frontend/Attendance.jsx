import { useState, useEffect, useCallback } from "react";
import { attendanceAPI, employeeAPI, leaveAPI } from "./api";

const dayColors = {
  Present: { bg:"rgba(0,212,180,0.15)",  color:"#00d4b4" },
  Absent:  { bg:"rgba(255,107,107,0.15)",color:"#ff6b6b" },
  Leave:   { bg:"rgba(255,201,74,0.15)", color:"#ffc94a" },
  WFH:     { bg:"rgba(79,139,255,0.15)", color:"#4f8bff" },
  Holiday: { bg:"rgba(167,139,250,0.15)",color:"#a78bfa" },
};

const STATUSES = ["Present","Absent","Leave","WFH","Holiday"];

export default function Attendance({ user }) {
  const now         = new Date();
  const [month,   setMonth]   = useState(now.getMonth() + 1);
  const [year,    setYear]    = useState(now.getFullYear());
  const [tab,     setTab]     = useState("calendar");
  const [records, setRecords] = useState([]);
  const [leaves,  setLeaves]  = useState([]);
  const [summary, setSummary] = useState({});
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState("");
  const [saving,  setSaving]  = useState(false);

  const isEmployee   = user?.role === "employee";
  const canManage    = ["admin","hr","manager"].includes(user?.role);

  const fetchData = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [attRes, leaveRes, summaryRes] = await Promise.all([
        attendanceAPI.getAll({ month, year }),
        leaveAPI.getAll({}),
        attendanceAPI.getSummary({ month, year }),
      ]);
      setRecords(attRes);
      setLeaves(leaveRes);
      // Build summary map from aggregation
      const map = {};
      summaryRes.forEach(s => { map[s._id] = s.count; });
      setSummary(map);

      if (!isEmployee) {
        const empRes = await employeeAPI.getAll({});
        setEmployees(empRes.employees || []);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [month, year, isEmployee]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Build calendar map: { employeeId: { day: status } }
  const calMap = {};
  records.forEach(r => {
    const empId = r.employee?._id || r.employee;
    if (!calMap[empId]) calMap[empId] = {};
    calMap[empId][new Date(r.date).getDate()] = r.status;
  });

  const daysInMonth = new Date(year, month, 0).getDate();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  // Employees shown in calendar: all active emps (HR) or just self
  const calEmployees = isEmployee
    ? (user.employeeId ? [{ _id: user.employeeId, name: user.name, avatar: user.name?.slice(0,2).toUpperCase(), color:"#4f8bff" }] : [])
    : employees;

  const approveLeave = async (id) => {
    setSaving(true);
    try {
      await leaveAPI.updateStatus(id, "Approved");
      fetchData();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const rejectLeave = async (id) => {
    setSaving(true);
    try {
      await leaveAPI.updateStatus(id, "Rejected");
      fetchData();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const applyLeave = async (form) => {
    setSaving(true);
    try {
      await leaveAPI.apply(form);
      fetchData();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Attendance</h1>
          <p className="page-subtitle">{MONTHS[month-1]} {year} attendance overview</p>
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <select className="select" style={{ width:"auto" }} value={month} onChange={e=>setMonth(Number(e.target.value))}>
            {MONTHS.map((m,i)=><option key={m} value={i+1}>{m}</option>)}
          </select>
          <select className="select" style={{ width:"auto" }} value={year} onChange={e=>setYear(Number(e.target.value))}>
            {[2024,2025,2026].map(y=><option key={y}>{y}</option>)}
          </select>
        </div>
      </div>

      <div className="stat-grid">
        {[
          { label:"Present", value:summary["Present"]||0, icon:"✅", color:"green"  },
          { label:"Absent",  value:summary["Absent"] ||0, icon:"❌", color:"red"    },
          { label:"On Leave",value:summary["Leave"]  ||0, icon:"🏖", color:"yellow" },
          { label:"WFH",     value:summary["WFH"]    ||0, icon:"🏠", color:"blue"   },
        ].map(s=>(
          <div className={`stat-card ${s.color}`} key={s.label}>
            <div className="stat-icon" style={{ background:"var(--bg-hover)" }}>{s.icon}</div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="tabs">
        <button className={`tab ${tab==="calendar"?"active":""}`} onClick={()=>setTab("calendar")}>Calendar View</button>
        <button className={`tab ${tab==="leaves"?"active":""}`}   onClick={()=>setTab("leaves")}>Leave Requests</button>
        {isEmployee && <button className={`tab ${tab==="apply"?"active":""}`} onClick={()=>setTab("apply")}>Apply Leave</button>}
      </div>

      {error && <div className="auth-error" style={{ marginBottom:16 }}>{error}</div>}

      {tab==="calendar" && (
        <div className="card">
          {loading ? (
            <div style={{ textAlign:"center", padding:40, color:"var(--text-muted)" }}>Loading attendance…</div>
          ) : (
            <div style={{ overflowX:"auto" }}>
              <table style={{ minWidth: calEmployees.length ? 900 : "auto" }}>
                <thead>
                  <tr>
                    <th style={{ minWidth:140 }}>Employee</th>
                    {days.map(d=><th key={d} style={{ textAlign:"center", padding:"8px 4px", minWidth:32 }}>{d}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {calEmployees.map(emp=>(
                    <tr key={emp._id}>
                      <td style={{ fontWeight:600, fontSize:13 }}>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          <div className="avatar" style={{ background:(emp.color||"#4f8bff")+"22", color:emp.color||"#4f8bff", width:28, height:28, fontSize:11 }}>{emp.avatar}</div>
                          {emp.name}
                        </div>
                      </td>
                      {days.map(d=>{
                        const s  = calMap[emp._id]?.[d];
                        const dc = s ? (dayColors[s]||{}) : {};
                        return (
                          <td key={d} style={{ textAlign:"center", padding:"6px 2px" }}>
                            <span style={{
                              display:"inline-block", width:28, height:28,
                              borderRadius:6, background:dc.bg||"transparent",
                              color:dc.color||"var(--text-muted)",
                              fontSize:10, fontWeight:700, lineHeight:"28px", textAlign:"center",
                            }}>
                              {s==="Present"?"P":s==="Absent"?"A":s==="Leave"?"L":s==="WFH"?"W":s==="Holiday"?"H":"·"}
                            </span>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                  {calEmployees.length === 0 && (
                    <tr><td colSpan={days.length+1} style={{ textAlign:"center", color:"var(--text-muted)", padding:40 }}>No attendance data.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
          <div style={{ display:"flex", gap:20, marginTop:20, flexWrap:"wrap" }}>
            {Object.entries(dayColors).map(([label,style])=>(
              <div key={label} style={{ display:"flex", alignItems:"center", gap:6 }}>
                <div style={{ width:14, height:14, borderRadius:4, background:style.bg, border:`1px solid ${style.color}` }}/>
                <span style={{ fontSize:12, color:"var(--text-secondary)" }}>{label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab==="leaves" && (
        <div className="card">
          <div className="table-wrap">
            {loading ? (
              <div style={{ textAlign:"center", padding:40, color:"var(--text-muted)" }}>Loading…</div>
            ) : (
              <table>
                <thead>
                  <tr><th>Employee</th><th>Leave Type</th><th>From</th><th>To</th><th>Days</th><th>Reason</th><th>Status</th>{canManage && <th>Actions</th>}</tr>
                </thead>
                <tbody>
                  {leaves.map(l=>(
                    <tr key={l._id}>
                      <td style={{ fontWeight:600 }}>{l.employee?.name || user?.name}</td>
                      <td><span className="badge badge-blue">{l.type}</span></td>
                      <td style={{ color:"var(--text-secondary)" }}>{l.from?.slice(0,10)}</td>
                      <td style={{ color:"var(--text-secondary)" }}>{l.to?.slice(0,10)}</td>
                      <td style={{ fontWeight:600 }}>{l.days}</td>
                      <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{l.reason}</td>
                      <td>
                        {l.status==="Approved" && <span className="badge badge-green">Approved</span>}
                        {l.status==="Pending"  && <span className="badge badge-yellow">Pending</span>}
                        {l.status==="Rejected" && <span className="badge badge-red">Rejected</span>}
                      </td>
                      {canManage && (
                        <td>
                          {l.status==="Pending" && (
                            <div style={{ display:"flex", gap:6 }}>
                              <button className="btn btn-success" style={{ padding:"5px 10px", fontSize:12 }} onClick={()=>approveLeave(l._id)} disabled={saving}>Approve</button>
                              <button className="btn btn-danger"  style={{ padding:"5px 10px", fontSize:12 }} onClick={()=>rejectLeave(l._id)} disabled={saving}>Reject</button>
                            </div>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                  {leaves.length===0 && (
                    <tr><td colSpan={canManage?8:7} style={{ textAlign:"center", color:"var(--text-muted)", padding:40 }}>No leave records found.</td></tr>
                  )}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {tab==="apply" && isEmployee && (
        <ApplyLeaveForm user={user} onApply={applyLeave} saving={saving} />
      )}
    </div>
  );
}

function ApplyLeaveForm({ user, onApply, saving }) {
  const LEAVE_TYPES = ["Sick Leave","Casual Leave","Earned Leave","WFH","Maternity Leave","Paternity Leave"];
  const [form, setForm] = useState({ type:"Sick Leave", from:"", to:"", reason:"" });
  const f = field => e => setForm({ ...form, [field]: e.target.value });

  const handleSubmit = () => {
    if (!form.from || !form.to || !form.reason.trim()) {
      alert("Please fill in all fields."); return;
    }
    if (new Date(form.to) < new Date(form.from)) {
      alert("End date must be after start date."); return;
    }
    onApply(form);
    setForm({ type:"Sick Leave", from:"", to:"", reason:"" });
  };

  // Show remaining balance
  const bal = user?.leaveBalance?.find(b => b.type === form.type);
  const available = bal ? bal.total - bal.used - (bal.pending || 0) : null;

  return (
    <div className="card" style={{ maxWidth:520 }}>
      <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>Apply for Leave</h3>

      {user?.leaveBalance && (
        <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginBottom:20 }}>
          {user.leaveBalance.map(b=>(
            <div key={b.type} style={{ background:"var(--bg-secondary)", borderRadius:8, padding:"8px 12px", fontSize:12 }}>
              <div style={{ fontWeight:700, color:"var(--text-primary)" }}>{b.type.replace(" Leave","")}</div>
              <div style={{ color:"var(--text-secondary)" }}>
                {b.total - b.used - (b.pending||0)} / {b.total} left
                {b.pending > 0 && <span style={{ color:"var(--accent-4)", marginLeft:4 }}>({b.pending} pending)</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="form-group">
        <label className="form-label">Leave Type</label>
        <select className="select" value={form.type} onChange={f("type")}>
          {LEAVE_TYPES.map(t=><option key={t}>{t}</option>)}
        </select>
        {available !== null && (
          <p style={{ fontSize:12, color: available > 0 ? "var(--accent-2)" : "var(--accent-3)", marginTop:4 }}>
            {available > 0 ? `${available} days available` : "No balance remaining"}
          </p>
        )}
      </div>
      <div className="form-row">
        <div className="form-group">
          <label className="form-label">From Date</label>
          <input className="input" type="date" value={form.from} onChange={f("from")} />
        </div>
        <div className="form-group">
          <label className="form-label">To Date</label>
          <input className="input" type="date" value={form.to} onChange={f("to")} />
        </div>
      </div>
      <div className="form-group">
        <label className="form-label">Reason</label>
        <input className="input" placeholder="Briefly explain your reason…" value={form.reason} onChange={f("reason")} />
      </div>
      <button className="btn btn-primary" onClick={handleSubmit} disabled={saving || available === 0} style={{ marginTop:4 }}>
        {saving ? "Submitting…" : "Submit Application"}
      </button>
    </div>
  );
}
