import { useState, useEffect, useCallback } from "react";
import { employeeAPI } from "./api";
import EmployeeDetail from "./EmployeeDetail";

const DEPTS    = ["Engineering","Sales","Marketing","HR","Finance","Operations"];
const STATUSES = ["Active","On Leave","Inactive"];
const COLORS   = ["#4f8bff","#00d4b4","#ffc94a","#ff6b6b","#a78bfa","#34d399"];
const EMPTY_FORM = { name:"", role:"", dept:"", email:"", phone:"", status:"Active", joined:"", salary:"", manager:"", address:"", dob:"", gender:"Male", blood:"O+", emergency:"", pan:"", bank:"", notes:"" };

export default function Employees() {
  const [employees,    setEmployees]    = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [error,        setError]        = useState("");
  const [search,       setSearch]       = useState("");
  const [filterDept,   setFilterDept]   = useState("All");
  const [filterStatus, setFilterStatus] = useState("All");
  const [showModal,    setShowModal]    = useState(false);
  const [editId,       setEditId]       = useState(null);
  const [form,         setForm]         = useState(EMPTY_FORM);
  const [deleteId,     setDeleteId]     = useState(null);
  const [viewEmp,      setViewEmp]      = useState(null);
  const [saving,       setSaving]       = useState(false);

  // ── Fetch employees from backend ─────────────────────────────────
  const fetchEmployees = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const params = {};
      if (filterDept   !== "All") params.dept   = filterDept;
      if (filterStatus !== "All") params.status = filterStatus;
      if (search.trim())          params.search = search.trim();
      const data = await employeeAPI.getAll(params);
      setEmployees(data.employees || []);
    } catch (err) {
      setError(err.message || "Failed to load employees.");
    } finally {
      setLoading(false);
    }
  }, [search, filterDept, filterStatus]);

  useEffect(() => {
    const t = setTimeout(fetchEmployees, 300); // debounce search
    return () => clearTimeout(t);
  }, [fetchEmployees]);

  // ── Helpers ──────────────────────────────────────────────────────
  const f = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const openAdd  = () => { setForm(EMPTY_FORM); setEditId(null); setShowModal(true); };
  const openEdit = (emp) => {
    setForm({
      ...EMPTY_FORM, ...emp,
      joined: emp.joined ? emp.joined.slice(0, 10) : "",
      dob:    emp.dob    ? emp.dob.slice(0, 10)    : "",
      salary: emp.salary ?? "",
    });
    setEditId(emp._id);
    setShowModal(true);
  };
  const closeModal = () => { setShowModal(false); setEditId(null); };

  const handleSave = async () => {
    if (!form.name.trim() || !form.email.trim()) return;
    setSaving(true);
    try {
      const payload = {
        ...form,
        salary: Number(form.salary) || 0,
        avatar: form.name.split(" ").map(w => w[0]).join("").slice(0,2).toUpperCase(),
        color: form.color || COLORS[Math.floor(Math.random() * COLORS.length)],
      };
      if (editId) {
        await employeeAPI.update(editId, payload);
      } else {
        await employeeAPI.create(payload);
      }
      closeModal();
      fetchEmployees();
    } catch (err) {
      alert(err.message || "Save failed.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await employeeAPI.remove(id);
      setDeleteId(null);
      setViewEmp(null);
      fetchEmployees();
    } catch (err) {
      alert(err.message || "Delete failed.");
    }
  };

  const updateEmployee = async (updated) => {
    try {
      await employeeAPI.update(updated._id, updated);
      fetchEmployees();
    } catch (err) {
      alert(err.message || "Update failed.");
    }
  };

  const badge = (s) =>
    s === "Active"   ? <span className="badge badge-green">{s}</span>  :
    s === "On Leave" ? <span className="badge badge-yellow">{s}</span> :
                       <span className="badge badge-gray">{s}</span>;

  // ── Employee detail view ────────────────────────────────────────
  if (viewEmp) {
    const live = employees.find(e => e._id === viewEmp._id) || viewEmp;
    return (
      <EmployeeDetail
        employee={live}
        onBack={() => setViewEmp(null)}
        onUpdate={updateEmployee}
        onDelete={handleDelete}
        onEdit={(emp) => { openEdit(emp); setViewEmp(null); }}
      />
    );
  }

  // ── List view ───────────────────────────────────────────────────
  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Employees</h1>
          <p className="page-subtitle">
            {loading ? "Loading…" : `${employees.length} total · ${employees.filter(e=>e.status==="Active").length} active`}
          </p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Employee</button>
      </div>

      {/* Filters */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ display:"flex", gap:12, flexWrap:"wrap" }}>
          <div className="search-bar" style={{ maxWidth:320 }}>
            <span style={{ color:"var(--text-muted)" }}>🔍</span>
            <input placeholder="Search by name, role, email…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <select className="select" style={{ width:"auto" }} value={filterDept} onChange={e=>setFilterDept(e.target.value)}>
            <option value="All">All Departments</option>
            {DEPTS.map(d=><option key={d}>{d}</option>)}
          </select>
          <select className="select" style={{ width:"auto" }} value={filterStatus} onChange={e=>setFilterStatus(e.target.value)}>
            <option value="All">All Statuses</option>
            {STATUSES.map(s=><option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {/* Error */}
      {error && <div className="auth-error" style={{ marginBottom:16 }}>{error}</div>}

      {/* Table */}
      <div className="card">
        <div className="table-wrap">
          {loading ? (
            <div style={{ textAlign:"center", padding:40, color:"var(--text-muted)" }}>Loading employees…</div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Employee</th><th>Role</th><th>Department</th>
                  <th>Email</th><th>Phone</th><th>Joined</th>
                  <th>Salary</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {employees.map((emp) => (
                  <tr key={emp._id}>
                    <td>
                      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                        <div className="avatar" style={{ background:(emp.color||"#4f8bff")+"22", color:emp.color||"#4f8bff" }}>{emp.avatar}</div>
                        <span style={{ fontWeight:600 }}>{emp.name}</span>
                      </div>
                    </td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{emp.role}</td>
                    <td><span className="badge badge-blue">{emp.dept}</span></td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{emp.email}</td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{emp.phone}</td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{emp.joined ? emp.joined.slice(0,10) : ""}</td>
                    <td style={{ fontWeight:600 }}>₹{Number(emp.salary).toLocaleString()}</td>
                    <td>{badge(emp.status)}</td>
                    <td>
                      <div style={{ display:"flex", gap:6 }}>
                        <button className="btn btn-primary" style={{ padding:"6px 12px", fontSize:12 }} onClick={()=>setViewEmp(emp)}>View</button>
                        <button className="btn btn-ghost"   style={{ padding:"6px 12px", fontSize:12 }} onClick={()=>openEdit(emp)}>Edit</button>
                        <button className="btn btn-danger"  style={{ padding:"6px 12px", fontSize:12 }} onClick={()=>setDeleteId(emp._id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {!loading && employees.length===0 && (
                  <tr><td colSpan={9} style={{ textAlign:"center", color:"var(--text-muted)", padding:40 }}>No employees found.</td></tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal" style={{ maxWidth:600 }} onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">{editId ? "Edit Employee" : "Add Employee"}</h2>
              <button className="modal-close" onClick={closeModal}>✕</button>
            </div>
            <div style={{ maxHeight:"70vh", overflowY:"auto", paddingRight:4 }}>
              <Sect>Basic Info</Sect>
              <div className="form-row">
                <FG label="Full Name *"><input className="input" placeholder="e.g. Riya Sharma"     value={form.name}   onChange={f("name")}   /></FG>
                <FG label="Role *">     <input className="input" placeholder="e.g. Developer"       value={form.role}   onChange={f("role")}   /></FG>
              </div>
              <div className="form-row">
                <FG label="Department"><select className="select" value={form.dept}   onChange={f("dept")}  ><option value="">Select</option>{DEPTS.map(d=><option key={d}>{d}</option>)}</select></FG>
                <FG label="Status">    <select className="select" value={form.status} onChange={f("status")}>{STATUSES.map(s=><option key={s}>{s}</option>)}</select></FG>
              </div>
              <div className="form-row">
                <FG label="Email *"><input className="input" type="email" placeholder="email@company.com" value={form.email}  onChange={f("email")}  /></FG>
                <FG label="Phone">  <input className="input"              placeholder="10-digit number"   value={form.phone}  onChange={f("phone")}  /></FG>
              </div>
              <div className="form-row">
                <FG label="Date of Joining"><input className="input" type="date"   value={form.joined}  onChange={f("joined")}  /></FG>
                <FG label="Salary (₹)">     <input className="input" type="number" value={form.salary}  onChange={f("salary")}  placeholder="e.g. 70000" /></FG>
              </div>
              <div className="form-row">
                <FG label="Reporting Manager"><input className="input" placeholder="Manager name" value={form.manager} onChange={f("manager")} /></FG>
                <FG label="Gender"><select className="select" value={form.gender} onChange={f("gender")}>{["Male","Female","Other"].map(g=><option key={g}>{g}</option>)}</select></FG>
              </div>
              <Sect>Personal Details</Sect>
              <div className="form-row">
                <FG label="Date of Birth"><input className="input" type="date" value={form.dob}  onChange={f("dob")}  /></FG>
                <FG label="Blood Group"><select className="select" value={form.blood} onChange={f("blood")}>{["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(b=><option key={b}>{b}</option>)}</select></FG>
              </div>
              <FG label="Address"><input className="input" placeholder="Full address" value={form.address} onChange={f("address")} /></FG>
              <div className="form-row">
                <FG label="Emergency Contact"><input className="input" placeholder="Phone number"   value={form.emergency} onChange={f("emergency")} /></FG>
                <FG label="PAN Number">       <input className="input" placeholder="ABCDE1234F"     value={form.pan}       onChange={f("pan")}       /></FG>
              </div>
              <FG label="Bank Account"><input className="input" placeholder="Bank – Account number" value={form.bank}  onChange={f("bank")}  /></FG>
              <FG label="Notes">       <input className="input" placeholder="Any notes"             value={form.notes} onChange={f("notes")} /></FG>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={closeModal} disabled={saving}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>{saving ? "Saving…" : editId ? "Save Changes" : "Add Employee"}</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirm */}
      {deleteId && (
        <div className="modal-overlay" onClick={()=>setDeleteId(null)}>
          <div className="modal" style={{ maxWidth:380 }} onClick={e=>e.stopPropagation()}>
            <h2 className="modal-title" style={{ marginBottom:12 }}>Confirm Delete</h2>
            <p style={{ color:"var(--text-secondary)", fontSize:14 }}>Are you sure? This cannot be undone.</p>
            <div className="modal-footer">
              <button className="btn btn-ghost"  onClick={()=>setDeleteId(null)}>Cancel</button>
              <button className="btn btn-danger" onClick={()=>handleDelete(deleteId)}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FG({ label, children }) {
  return <div className="form-group"><label className="form-label">{label}</label>{children}</div>;
}
function Sect({ children }) {
  return <p style={{ fontSize:11, color:"var(--text-muted)", marginBottom:10, marginTop:8, textTransform:"uppercase", letterSpacing:1, fontWeight:700 }}>{children}</p>;
}
