import { useState } from "react";
import { useLocalStorage } from "../hooks/useLocalStorage";
import "./EmployeeDetail.css";

/* ── seed helpers (only used when no saved data exists) ── */
const genAttendance = () => {
  const types = ["Present","Present","Present","Absent","Leave","WFH","Present"];
  return Array.from({ length:31 }, (_,i) => ({
    day: i+1,
    status: types[Math.floor(Math.random()*types.length)],
    inTime:"09:12 AM", outTime:"06:30 PM",
  }));
};
const genPayslips = (salary) => ["May 2025","Apr 2025","Mar 2025"].map(month => ({
  month, basic:salary,
  hra: Math.round(salary*0.2),
  ta: 5000,
  deductions: Math.round(salary*0.1),
  status:"Processed",
}));
const genLeaves = () => [
  { id:1, type:"Sick Leave",    from:"2025-05-03", to:"2025-05-04", days:2, reason:"Fever",         status:"Approved" },
  { id:2, type:"Casual Leave",  from:"2025-04-18", to:"2025-04-18", days:1, reason:"Personal work",  status:"Approved" },
  { id:3, type:"Earned Leave",  from:"2025-06-10", to:"2025-06-13", days:4, reason:"Vacation",       status:"Pending"  },
];
const genPerf = () => ({
  score: Math.floor(Math.random()*25)+70,
  rating:["Good","Very Good","Excellent","Outstanding"][Math.floor(Math.random()*4)],
  goals:5, goalsmet: Math.floor(Math.random()*2)+3,
  skills:[
    { name:"Communication",  score: Math.floor(Math.random()*25)+70 },
    { name:"Technical Skills",score: Math.floor(Math.random()*25)+70 },
    { name:"Teamwork",       score: Math.floor(Math.random()*25)+70 },
    { name:"Leadership",     score: Math.floor(Math.random()*25)+70 },
    { name:"Punctuality",    score: Math.floor(Math.random()*25)+70 },
  ],
  feedback:"Consistently delivers quality work on time. Shows great initiative.",
});

const dayColors = {
  Present:{ bg:"rgba(0,212,180,0.15)", color:"#00d4b4", label:"P" },
  Absent: { bg:"rgba(255,107,107,0.15)",color:"#ff6b6b", label:"A" },
  Leave:  { bg:"rgba(255,201,74,0.15)", color:"#ffc94a", label:"L" },
  WFH:    { bg:"rgba(79,139,255,0.15)", color:"#4f8bff", label:"W" },
};
const scoreColor = (s) => s>=90?"var(--accent-2)":s>=75?"var(--accent)":s>=60?"var(--accent-4)":"var(--accent-3)";
const TABS = ["Profile","Attendance","Payroll","Leave","Performance","Documents"];

export default function EmployeeDetail({ employee, onBack, onUpdate, onDelete }) {
  const empKey = `hrms_emp_${employee.id}`;

  /* All per-employee data persisted separately */
  const [emp,        setEmp]        = useLocalStorage(empKey+"_info",       employee);
  const [attendance]                = useLocalStorage(empKey+"_attendance",  genAttendance());
  const [payslips,   setPayslips]   = useLocalStorage(empKey+"_payslips",   genPayslips(employee.salary));
  const [leaves,     setLeaves]     = useLocalStorage(empKey+"_leaves",     genLeaves());
  const [perf]                      = useLocalStorage(empKey+"_perf",       genPerf());

  const [tab,           setTab]           = useState("Profile");
  const [editing,       setEditing]       = useState(false);
  const [editForm,      setEditForm]      = useState({ ...emp });
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [leaveModal,    setLeaveModal]    = useState(false);
  const [newLeave,      setNewLeave]      = useState({ type:"Sick Leave", from:"", to:"", reason:"" });
  const [salaryModal,   setSalaryModal]   = useState(false);
  const [newSalary,     setNewSalary]     = useState(emp.salary);
  const [statusModal,   setStatusModal]   = useState(false);
  const [newStatus,     setNewStatus]     = useState(emp.status);
  const [toast,         setToast]         = useState("");

  const showToast = (msg) => { setToast(msg); setTimeout(()=>setToast(""), 2800); };

  const saveAndSync = (updated) => {
    setEmp(updated);
    onUpdate(updated);
  };

  /* Save profile edits */
  const saveProfile = () => {
    const updated = { ...emp, ...editForm, salary:Number(editForm.salary) };
    saveAndSync(updated);
    setEditing(false);
    showToast("Profile saved ✓");
  };

  /* Apply leave */
  const applyLeave = () => {
    if (!newLeave.from||!newLeave.to||!newLeave.reason) return;
    const days = Math.max(1, Math.round((new Date(newLeave.to)-new Date(newLeave.from))/86400000)+1);
    setLeaves([...leaves, { id:Date.now(), ...newLeave, days, status:"Pending" }]);
    setLeaveModal(false);
    setNewLeave({ type:"Sick Leave", from:"", to:"", reason:"" });
    showToast("Leave request submitted ✓");
  };

  const updateLeaveStatus = (id, status) => {
    setLeaves(leaves.map(l=>l.id===id?{...l,status}:l));
    showToast(`Leave ${status.toLowerCase()} ✓`);
  };

  /* Revise salary */
  const saveSalary = () => {
    const updated = { ...emp, salary:Number(newSalary) };
    saveAndSync(updated);
    /* add a new payslip row for current month */
    const s = Number(newSalary);
    setPayslips([{ month:"Jun 2025", basic:s, hra:Math.round(s*0.2), ta:5000, deductions:Math.round(s*0.1), status:"Pending" }, ...payslips]);
    setSalaryModal(false);
    showToast("Salary revised ✓");
  };

  /* Change status */
  const saveStatus = () => {
    const updated = { ...emp, status:newStatus };
    saveAndSync(updated);
    setStatusModal(false);
    showToast(`Status → ${newStatus} ✓`);
  };

  const present = attendance.filter(a=>a.status==="Present").length;
  const absent  = attendance.filter(a=>a.status==="Absent").length;
  const leave   = attendance.filter(a=>a.status==="Leave").length;
  const wfh     = attendance.filter(a=>a.status==="WFH").length;

  const badge = (s) =>
    s==="Active"   ? <span className="badge badge-green">{s}</span>  :
    s==="On Leave" ? <span className="badge badge-yellow">{s}</span> :
                     <span className="badge badge-gray">{s}</span>;

  const ef = (field) => (e) => setEditForm({ ...editForm, [field]:e.target.value });

  return (
    <div className="emp-detail">
      {toast && <div className="emp-toast">{toast}</div>}

      {/* Header bar */}
      <div className="emp-detail-header">
        <button className="btn btn-ghost" onClick={onBack}>← Back to Employees</button>
        <div className="emp-header-actions">
          <button className="btn btn-ghost"  onClick={()=>{ setEditForm({...emp}); setEditing(true); }}>✏ Edit Profile</button>
          <button className="btn btn-ghost"  onClick={()=>{ setNewStatus(emp.status); setStatusModal(true); }}>🔄 Change Status</button>
          <button className="btn btn-ghost"  onClick={()=>{ setNewSalary(emp.salary); setSalaryModal(true); }}>💰 Revise Salary</button>
          <button className="btn btn-danger" onClick={()=>setDeleteConfirm(true)}>🗑 Delete</button>
        </div>
      </div>

      {/* Banner */}
      <div className="emp-banner">
        <div className="emp-banner-bg" style={{ background:`linear-gradient(135deg,${emp.color}22,transparent)` }} />
        <div className="emp-banner-content">
          <div className="emp-avatar-lg" style={{ background:emp.color+"33", color:emp.color, border:`3px solid ${emp.color}55` }}>
            {emp.avatar}
          </div>
          <div className="emp-banner-info">
            <h2 className="emp-banner-name">{emp.name}</h2>
            <p className="emp-banner-role">{emp.role} · {emp.dept}</p>
            <div className="emp-banner-meta">
              <span>📧 {emp.email}</span>
              <span>📱 {emp.phone}</span>
              <span>📅 Joined {emp.joined}</span>
              <span>👤 {emp.manager||"—"}</span>
            </div>
          </div>
          <div className="emp-banner-right">
            {badge(emp.status)}
            <div className="emp-salary-display">₹{Number(emp.salary).toLocaleString()}<span>/mo</span></div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs" style={{ marginBottom:24 }}>
        {TABS.map(t=>(
          <button key={t} className={`tab ${tab===t?"active":""}`} onClick={()=>setTab(t)}>{t}</button>
        ))}
      </div>

      {/* ── PROFILE ── */}
      {tab==="Profile" && (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20 }}>
          <InfoCard title="Personal Information" items={[
            { label:"Full Name",        value:emp.name },
            { label:"Gender",           value:emp.gender||"—" },
            { label:"Date of Birth",    value:emp.dob||"—" },
            { label:"Blood Group",      value:emp.blood||"—" },
            { label:"Address",          value:emp.address||"—" },
            { label:"Emergency Contact",value:emp.emergency||"—" },
          ]}/>
          <InfoCard title="Employment Details" items={[
            { label:"Employee ID",      value:`EMP-${String(emp.id).padStart(4,"0")}` },
            { label:"Department",       value:emp.dept },
            { label:"Role",             value:emp.role },
            { label:"Reporting Manager",value:emp.manager||"—" },
            { label:"Date of Joining",  value:emp.joined },
            { label:"Status",           value:emp.status },
          ]}/>
          <InfoCard title="Financial Details" items={[
            { label:"Monthly Salary",   value:`₹${Number(emp.salary).toLocaleString()}` },
            { label:"Annual CTC",       value:`₹${(Number(emp.salary)*12).toLocaleString()}` },
            { label:"PAN Number",       value:emp.pan||"—" },
            { label:"Bank Account",     value:emp.bank||"—" },
          ]}/>
          <div className="card">
            <h4 style={{ fontFamily:"Syne", fontWeight:700, fontSize:14, marginBottom:16, color:"var(--text-secondary)", textTransform:"uppercase", letterSpacing:"0.8px" }}>Notes</h4>
            <p style={{ fontSize:14, color:"var(--text-primary)", lineHeight:1.7 }}>{emp.notes||"No notes added."}</p>
          </div>
        </div>
      )}

      {/* ── ATTENDANCE ── */}
      {tab==="Attendance" && (
        <div>
          <div className="stat-grid" style={{ marginBottom:20 }}>
            {[
              { label:"Present", value:present, color:"green", icon:"✅" },
              { label:"Absent",  value:absent,  color:"red",   icon:"❌" },
              { label:"On Leave",value:leave,   color:"yellow",icon:"🏖" },
              { label:"WFH",     value:wfh,     color:"blue",  icon:"🏠" },
            ].map(s=>(
              <div className={`stat-card ${s.color}`} key={s.label}>
                <div className="stat-icon" style={{ background:"var(--bg-hover)" }}>{s.icon}</div>
                <div className="stat-value">{s.value}</div>
                <div className="stat-label">{s.label} · May 2025</div>
              </div>
            ))}
          </div>
          <div className="card">
            <h4 style={{ fontFamily:"Syne", fontWeight:700, fontSize:14, marginBottom:16 }}>Monthly Calendar — May 2025</h4>
            <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
              {attendance.map(a=>{
                const dc = dayColors[a.status]||{ bg:"var(--bg-hover)", color:"var(--text-muted)", label:"?" };
                return (
                  <div key={a.day} title={`Day ${a.day}: ${a.status}`} style={{
                    width:44, height:44, borderRadius:10,
                    background:dc.bg, color:dc.color,
                    display:"flex", flexDirection:"column",
                    alignItems:"center", justifyContent:"center",
                    fontSize:11, fontWeight:700,
                  }}>
                    <span style={{ fontSize:9, opacity:0.7 }}>{a.day}</span>
                    <span>{dc.label}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ display:"flex", gap:20, marginTop:16, flexWrap:"wrap" }}>
              {Object.entries(dayColors).map(([label,style])=>(
                <div key={label} style={{ display:"flex", alignItems:"center", gap:6 }}>
                  <div style={{ width:12, height:12, borderRadius:3, background:style.bg, border:`1px solid ${style.color}` }}/>
                  <span style={{ fontSize:12, color:"var(--text-secondary)" }}>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── PAYROLL ── */}
      {tab==="Payroll" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
            <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:16 }}>Payslip History</h3>
            <button className="btn btn-primary" onClick={()=>{ setNewSalary(emp.salary); setSalaryModal(true); }}>💰 Revise Salary</button>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
            {payslips.map((slip,i)=>{
              const net = slip.basic+slip.hra+slip.ta-slip.deductions;
              return (
                <div className="card" key={i}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16 }}>
                    <div>
                      <div style={{ fontFamily:"Syne", fontWeight:700, fontSize:15 }}>{slip.month}</div>
                      <span className={`badge ${slip.status==="Processed"?"badge-green":"badge-yellow"}`} style={{ marginTop:6 }}>{slip.status}</span>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <div style={{ fontFamily:"Syne", fontWeight:800, fontSize:22, color:"var(--accent-2)" }}>₹{net.toLocaleString()}</div>
                      <div style={{ fontSize:12, color:"var(--text-muted)" }}>Net Pay</div>
                    </div>
                  </div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
                    {[
                      { label:"Basic",      value:slip.basic,      color:"var(--text-primary)" },
                      { label:"HRA",        value:slip.hra,        color:"var(--text-primary)" },
                      { label:"Travel",     value:slip.ta,         color:"var(--text-primary)" },
                      { label:"Deductions", value:slip.deductions, color:"var(--accent-3)" },
                    ].map(r=>(
                      <div key={r.label} style={{ background:"var(--bg-secondary)", borderRadius:10, padding:"12px 14px" }}>
                        <div style={{ fontSize:11, color:"var(--text-muted)", marginBottom:4, textTransform:"uppercase" }}>{r.label}</div>
                        <div style={{ fontWeight:700, color:r.color, fontSize:15 }}>
                          {r.label==="Deductions"?`-₹${r.value.toLocaleString()}`:`₹${r.value.toLocaleString()}`}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── LEAVE ── */}
      {tab==="Leave" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
            <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:16 }}>Leave Management</h3>
            <button className="btn btn-primary" onClick={()=>setLeaveModal(true)}>+ Apply Leave</button>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:16, marginBottom:24 }}>
            {[
              { label:"Total Leaves",  value:24, color:"blue" },
              { label:"Used",          value:leaves.filter(l=>l.status==="Approved").reduce((s,l)=>s+l.days,0), color:"yellow" },
              { label:"Pending",       value:leaves.filter(l=>l.status==="Pending").length, color:"red" },
              { label:"Remaining",     value:24-leaves.filter(l=>l.status==="Approved").reduce((s,l)=>s+l.days,0), color:"green" },
            ].map(s=>(
              <div className={`stat-card ${s.color}`} key={s.label}>
                <div className="stat-value" style={{ fontSize:28 }}>{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>
          <div className="card">
            <div className="table-wrap">
              <table>
                <thead><tr><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  {leaves.map(l=>(
                    <tr key={l.id}>
                      <td><span className="badge badge-blue">{l.type}</span></td>
                      <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{l.from}</td>
                      <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{l.to}</td>
                      <td style={{ fontWeight:600 }}>{l.days}</td>
                      <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{l.reason}</td>
                      <td>
                        {l.status==="Approved" && <span className="badge badge-green">Approved</span>}
                        {l.status==="Pending"  && <span className="badge badge-yellow">Pending</span>}
                        {l.status==="Rejected" && <span className="badge badge-red">Rejected</span>}
                      </td>
                      <td>
                        {l.status==="Pending" && (
                          <div style={{ display:"flex", gap:6 }}>
                            <button className="btn btn-success" style={{ padding:"4px 10px", fontSize:12 }} onClick={()=>updateLeaveStatus(l.id,"Approved")}>Approve</button>
                            <button className="btn btn-danger"  style={{ padding:"4px 10px", fontSize:12 }} onClick={()=>updateLeaveStatus(l.id,"Rejected")}>Reject</button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                  {leaves.length===0 && (
                    <tr><td colSpan={7} style={{ textAlign:"center", color:"var(--text-muted)", padding:32 }}>No leave records yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── PERFORMANCE ── */}
      {tab==="Performance" && (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20 }}>
          <div className="card">
            <h4 style={{ fontFamily:"Syne", fontWeight:700, fontSize:14, marginBottom:20 }}>Q1 2025 Overview</h4>
            <div style={{ textAlign:"center", marginBottom:24 }}>
              <div style={{ fontSize:56, fontWeight:800, fontFamily:"Syne", color:scoreColor(perf.score) }}>{perf.score}</div>
              <span className={`badge ${perf.score>=90?"badge-green":perf.score>=75?"badge-blue":"badge-yellow"}`}>{perf.rating}</span>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
              {[
                { label:"Goals Set",   value:perf.goals },
                { label:"Goals Met",   value:perf.goalsmet },
                { label:"Completion",  value:`${Math.round((perf.goalsmet/perf.goals)*100)}%` },
                { label:"Period",      value:"Q1 2025" },
              ].map(f=>(
                <div key={f.label} style={{ background:"var(--bg-secondary)", borderRadius:10, padding:"12px 14px" }}>
                  <div style={{ fontSize:11, color:"var(--text-muted)", marginBottom:4, textTransform:"uppercase" }}>{f.label}</div>
                  <div style={{ fontWeight:700, fontSize:16 }}>{f.value}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <h4 style={{ fontFamily:"Syne", fontWeight:700, fontSize:14, marginBottom:20 }}>Skill Ratings</h4>
            {perf.skills.map(sk=>(
              <div key={sk.name} style={{ marginBottom:16 }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
                  <span style={{ fontSize:13 }}>{sk.name}</span>
                  <span style={{ fontSize:13, fontWeight:700, color:scoreColor(sk.score) }}>{sk.score}</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width:`${sk.score}%`, background:scoreColor(sk.score) }}/>
                </div>
              </div>
            ))}
          </div>
          <div className="card" style={{ gridColumn:"1/-1" }}>
            <h4 style={{ fontFamily:"Syne", fontWeight:700, fontSize:14, marginBottom:12 }}>Manager Feedback</h4>
            <p style={{ fontSize:14, color:"var(--text-secondary)", lineHeight:1.7, background:"var(--bg-secondary)", padding:"14px 16px", borderRadius:10 }}>{perf.feedback}</p>
          </div>
        </div>
      )}

      {/* ── DOCUMENTS ── */}
      {tab==="Documents" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:20 }}>
            <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:16 }}>Employee Documents</h3>
            <button className="btn btn-primary">+ Upload Document</button>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))", gap:16 }}>
            {[
              { name:"Offer Letter",            icon:"📄", type:"PDF" },
              { name:"ID Proof (Aadhaar)",       icon:"🪪", type:"IMG" },
              { name:"PAN Card",                 icon:"💳", type:"IMG" },
              { name:"Educational Certificates", icon:"🎓", type:"PDF" },
              { name:"Bank Details Form",        icon:"🏦", type:"PDF" },
              { name:"NDA / Agreement",          icon:"📝", type:"PDF" },
            ].map(doc=>(
              <div className="card" key={doc.name} style={{ display:"flex", flexDirection:"column", gap:12 }}>
                <div style={{ fontSize:32 }}>{doc.icon}</div>
                <div>
                  <div style={{ fontWeight:600, fontSize:14 }}>{doc.name}</div>
                  <div style={{ fontSize:12, color:"var(--text-muted)", marginTop:2 }}>Uploaded {emp.joined}</div>
                </div>
                <div style={{ display:"flex", gap:8, marginTop:"auto" }}>
                  <span className="badge badge-blue">{doc.type}</span>
                  <button className="btn btn-ghost" style={{ padding:"4px 10px", fontSize:12 }}>View</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── EDIT PROFILE MODAL ── */}
      {editing && (
        <div className="modal-overlay" onClick={()=>setEditing(false)}>
          <div className="modal" style={{ maxWidth:620 }} onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">Edit Profile — {emp.name}</h2>
              <button className="modal-close" onClick={()=>setEditing(false)}>✕</button>
            </div>
            <div style={{ maxHeight:"65vh", overflowY:"auto", paddingRight:4 }}>
              <Sect>Basic Info</Sect>
              <div className="form-row">
                <FG label="Full Name"><input className="input" value={editForm.name}  onChange={ef("name")}  /></FG>
                <FG label="Role">     <input className="input" value={editForm.role}  onChange={ef("role")}  /></FG>
              </div>
              <div className="form-row">
                <FG label="Department"><select className="select" value={editForm.dept}   onChange={ef("dept")}  >{["Engineering","Sales","Marketing","HR","Finance","Operations"].map(d=><option key={d}>{d}</option>)}</select></FG>
                <FG label="Status">    <select className="select" value={editForm.status} onChange={ef("status")}>{["Active","On Leave","Inactive"].map(s=><option key={s}>{s}</option>)}</select></FG>
              </div>
              <div className="form-row">
                <FG label="Email"><input className="input" type="email" value={editForm.email}  onChange={ef("email")}  /></FG>
                <FG label="Phone"><input className="input"              value={editForm.phone}  onChange={ef("phone")}  /></FG>
              </div>
              <div className="form-row">
                <FG label="Date of Joining">   <input className="input" type="date"   value={editForm.joined}  onChange={ef("joined")}  /></FG>
                <FG label="Reporting Manager"> <input className="input"               value={editForm.manager||""} onChange={ef("manager")} /></FG>
              </div>
              <Sect>Personal Details</Sect>
              <div className="form-row">
                <FG label="Date of Birth"><input className="input" type="date" value={editForm.dob||""}   onChange={ef("dob")}   /></FG>
                <FG label="Gender"><select className="select" value={editForm.gender||"Male"} onChange={ef("gender")}>{["Male","Female","Other"].map(g=><option key={g}>{g}</option>)}</select></FG>
              </div>
              <div className="form-row">
                <FG label="Blood Group"><select className="select" value={editForm.blood||"O+"} onChange={ef("blood")}>{["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(b=><option key={b}>{b}</option>)}</select></FG>
                <FG label="Emergency Contact"><input className="input" value={editForm.emergency||""} onChange={ef("emergency")} /></FG>
              </div>
              <FG label="Address"><input className="input" value={editForm.address||""} onChange={ef("address")} /></FG>
              <Sect>Financial</Sect>
              <div className="form-row">
                <FG label="Salary (₹)"> <input className="input" type="number" value={editForm.salary} onChange={ef("salary")} /></FG>
                <FG label="PAN Number"> <input className="input"               value={editForm.pan||""} onChange={ef("pan")}    /></FG>
              </div>
              <FG label="Bank Account"><input className="input" value={editForm.bank||""}  onChange={ef("bank")}  /></FG>
              <FG label="Notes">       <input className="input" value={editForm.notes||""} onChange={ef("notes")} /></FG>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={()=>setEditing(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={saveProfile}>Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {/* ── APPLY LEAVE MODAL ── */}
      {leaveModal && (
        <div className="modal-overlay" onClick={()=>setLeaveModal(false)}>
          <div className="modal" style={{ maxWidth:460 }} onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">Apply Leave</h2>
              <button className="modal-close" onClick={()=>setLeaveModal(false)}>✕</button>
            </div>
            <FG label="Leave Type">
              <select className="select" value={newLeave.type} onChange={e=>setNewLeave({...newLeave,type:e.target.value})}>
                {["Sick Leave","Casual Leave","Earned Leave","WFH","Maternity Leave"].map(t=><option key={t}>{t}</option>)}
              </select>
            </FG>
            <div className="form-row">
              <FG label="From Date"><input className="input" type="date" value={newLeave.from} onChange={e=>setNewLeave({...newLeave,from:e.target.value})} /></FG>
              <FG label="To Date">  <input className="input" type="date" value={newLeave.to}   onChange={e=>setNewLeave({...newLeave,to:e.target.value})}   /></FG>
            </div>
            <FG label="Reason"><input className="input" placeholder="Reason for leave" value={newLeave.reason} onChange={e=>setNewLeave({...newLeave,reason:e.target.value})} /></FG>
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={()=>setLeaveModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={applyLeave}>Submit Request</button>
            </div>
          </div>
        </div>
      )}

      {/* ── REVISE SALARY MODAL ── */}
      {salaryModal && (
        <div className="modal-overlay" onClick={()=>setSalaryModal(false)}>
          <div className="modal" style={{ maxWidth:400 }} onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">Revise Salary</h2>
              <button className="modal-close" onClick={()=>setSalaryModal(false)}>✕</button>
            </div>
            <p style={{ fontSize:13, color:"var(--text-secondary)", marginBottom:16 }}>
              Current: <strong style={{ color:"var(--accent-2)" }}>₹{Number(emp.salary).toLocaleString()}</strong>
            </p>
            <FG label="New Monthly Salary (₹)">
              <input className="input" type="number" value={newSalary} onChange={e=>setNewSalary(e.target.value)} />
            </FG>
            {newSalary && emp.salary && Number(newSalary)!==emp.salary && (
              <p style={{ fontSize:12, color:Number(newSalary)>emp.salary?"var(--accent-2)":"var(--accent-3)", marginTop:8 }}>
                {Number(newSalary)>emp.salary?"↑":"↓"} {Math.abs(((Number(newSalary)-emp.salary)/emp.salary)*100).toFixed(1)}% change
              </p>
            )}
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={()=>setSalaryModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={saveSalary}>Update Salary</button>
            </div>
          </div>
        </div>
      )}

      {/* ── CHANGE STATUS MODAL ── */}
      {statusModal && (
        <div className="modal-overlay" onClick={()=>setStatusModal(false)}>
          <div className="modal" style={{ maxWidth:380 }} onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">Change Status</h2>
              <button className="modal-close" onClick={()=>setStatusModal(false)}>✕</button>
            </div>
            <FG label="Employment Status">
              <select className="select" value={newStatus} onChange={e=>setNewStatus(e.target.value)}>
                {["Active","On Leave","Inactive"].map(s=><option key={s}>{s}</option>)}
              </select>
            </FG>
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={()=>setStatusModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={saveStatus}>Update Status</button>
            </div>
          </div>
        </div>
      )}

      {/* ── DELETE CONFIRM ── */}
      {deleteConfirm && (
        <div className="modal-overlay" onClick={()=>setDeleteConfirm(false)}>
          <div className="modal" style={{ maxWidth:380 }} onClick={e=>e.stopPropagation()}>
            <h2 className="modal-title" style={{ marginBottom:12 }}>Delete Employee</h2>
            <p style={{ color:"var(--text-secondary)", fontSize:14 }}>
              Permanently remove <strong>{emp.name}</strong>? This cannot be undone.
            </p>
            <div className="modal-footer">
              <button className="btn btn-ghost"  onClick={()=>setDeleteConfirm(false)}>Cancel</button>
              <button className="btn btn-danger" onClick={()=>onDelete(emp.id)}>Yes, Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function InfoCard({ title, items }) {
  return (
    <div className="card">
      <h4 style={{ fontFamily:"Syne", fontWeight:700, fontSize:14, marginBottom:16, color:"var(--text-secondary)", textTransform:"uppercase", letterSpacing:"0.8px" }}>{title}</h4>
      <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
        {items.map(item=>(
          <div key={item.label} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid var(--border)", fontSize:14 }}>
            <span style={{ color:"var(--text-secondary)" }}>{item.label}</span>
            <span style={{ fontWeight:600, textAlign:"right", maxWidth:"60%" }}>{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
function FG({ label, children }) {
  return <div className="form-group"><label className="form-label">{label}</label>{children}</div>;
}
function Sect({ children }) {
  return <p style={{ fontSize:11, color:"var(--text-muted)", marginBottom:10, marginTop:8, textTransform:"uppercase", letterSpacing:1, fontWeight:700 }}>{children}</p>;
}
