import { useState } from "react";

/**
 * useLocalStorage — drop-in replacement for useState that persists to localStorage.
 * Data survives page refresh and browser restart.
 *
 * @param {string} key       - localStorage key (must be unique per piece of data)
 * @param {any}    initial   - initial value if nothing is saved yet
 */
export function useLocalStorage(key, initial) {
  const [state, setState] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved !== null ? JSON.parse(saved) : initial;
    } catch {
      return initial;
    }
  });

  const setValue = (value) => {
    try {
      const toStore = typeof value === "function" ? value(state) : value;
      setState(toStore);
      localStorage.setItem(key, JSON.stringify(toStore));
    } catch (e) {
      console.error("localStorage write error:", e);
    }
  };

  return [state, setValue];
}

/**
 * clearAllHRMSData — wipe every HRMS key from localStorage.
 * Useful for a "Reset Demo Data" button.
 */
export function clearAllHRMSData() {
  const keys = [
    "hrms_employees",
    "hrms_leaves",
    "hrms_payroll",
    "hrms_jobs",
    "hrms_candidates",
    "hrms_reviews",
    "hrms_user",
  ];
  keys.forEach((k) => localStorage.removeItem(k));
}
