import { useState, useEffect, useCallback } from "react";
import { recruitmentAPI } from "./api";

const stages = ["Applied","Screening","Technical Interview","HR Round","Offer","Hired","Rejected"];
const DEPTS  = ["Engineering","Sales","Marketing","HR","Finance","Operations"];
const EMPTY_JOB = { title:"", dept:"", type:"Full-Time", openings:1, status:"Active" };
const EMPTY_CAND = { name:"", email:"", phone:"", job:"", stage:"Applied", score:0, notes:"" };

export default function Recruitment({ user }) {
  const [jobs,     setJobs]     = useState([]);
  const [cands,    setCands]    = useState([]);
  const [tab,      setTab]      = useState("jobs");
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState("");
  const [saving,   setSaving]   = useState(false);
  const [showJobModal,  setShowJobModal]  = useState(false);
  const [showCandModal, setShowCandModal] = useState(false);
  const [jobForm,  setJobForm]  = useState(EMPTY_JOB);
  const [candForm, setCandForm] = useState(EMPTY_CAND);
  const [editJobId, setEditJobId] = useState(null);

  const isEmployee = user?.role === "employee";
  const canManage  = ["admin","hr"].includes(user?.role);

  const fetchData = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [jobData, candData] = await Promise.all([
        recruitmentAPI.getJobs(),
        recruitmentAPI.getCandidates(),
      ]);
      setJobs(jobData);
      setCands(candData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const fj = field => e => setJobForm({ ...jobForm, [field]: e.target.value });
  const fc = field => e => setCandForm({ ...candForm, [field]: e.target.value });

  const handleAddJob = async () => {
    if (!jobForm.title) return;
    setSaving(true);
    try {
      if (editJobId) {
        await recruitmentAPI.updateJob(editJobId, jobForm);
      } else {
        await recruitmentAPI.createJob(jobForm);
      }
      setShowJobModal(false); setJobForm(EMPTY_JOB); setEditJobId(null);
      fetchData();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const handleDeleteJob = async (id) => {
    if (!confirm("Delete this job posting?")) return;
    try {
      await recruitmentAPI.deleteJob(id);
      fetchData();
    } catch (err) { alert(err.message); }
  };

  const handleAddCand = async () => {
    if (!candForm.name || !candForm.job) return;
    setSaving(true);
    try {
      await recruitmentAPI.addCandidate(candForm);
      setShowCandModal(false); setCandForm(EMPTY_CAND);
      fetchData();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const moveStage = async (id, stage) => {
    try {
      await recruitmentAPI.updateCandidateStage(id, { stage });
      fetchData();
    } catch (err) { alert(err.message); }
  };

  const deleteCand = async (id) => {
    if (!confirm("Remove this candidate?")) return;
    try {
      await recruitmentAPI.deleteCandidate(id);
      fetchData();
    } catch (err) { alert(err.message); }
  };

  const stageColor = (s) =>
    s==="Hired"?"badge-green":s==="Rejected"?"badge-red":
    s==="Offer"?"badge-blue":(s==="HR Round"||s==="Technical Interview")?"badge-yellow":"badge-gray";

  const pipeline = stages.slice(0,6).map(s => ({ stage:s, count:cands.filter(c=>c.stage===s).length }));

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Recruitment</h1>
          <p className="page-subtitle">Manage job postings and candidates</p>
        </div>
        {canManage && (
          <div style={{ display:"flex", gap:10 }}>
            <button className="btn btn-ghost"   onClick={()=>{ setCandForm(EMPTY_CAND); setShowCandModal(true); }}>+ Add Candidate</button>
            <button className="btn btn-primary" onClick={()=>{ setJobForm(EMPTY_JOB); setEditJobId(null); setShowJobModal(true); }}>+ Post Job</button>
          </div>
        )}
      </div>

      {/* Pipeline */}
      <div className="card" style={{ marginBottom:24 }}>
        <h3 style={{ fontSize:15, fontWeight:700, marginBottom:16 }}>Hiring Pipeline</h3>
        <div style={{ display:"flex" }}>
          {pipeline.map((p,i)=>(
            <div key={p.stage} style={{ flex:1, textAlign:"center" }}>
              <div style={{
                background: p.count>0?"var(--accent-soft)":"var(--bg-hover)",
                border:`1px solid ${p.count>0?"var(--accent)":"var(--border)"}`,
                borderRadius: i===0?"10px 0 0 10px":i===pipeline.length-1?"0 10px 10px 0":0,
                padding:"12px 8px",
              }}>
                <div style={{ fontSize:22, fontWeight:800, fontFamily:"Syne", color:p.count>0?"var(--accent)":"var(--text-muted)" }}>{p.count}</div>
                <div style={{ fontSize:11, color:"var(--text-secondary)", marginTop:2 }}>{p.stage}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {error && <div className="auth-error" style={{ marginBottom:16 }}>{error}</div>}

      <div className="tabs">
        <button className={`tab ${tab==="jobs"?"active":""}`}       onClick={()=>setTab("jobs")}>Job Postings</button>
        <button className={`tab ${tab==="candidates"?"active":""}`} onClick={()=>setTab("candidates")}>Candidates</button>
      </div>

      {loading ? (
        <div className="card" style={{ textAlign:"center", padding:60, color:"var(--text-muted)" }}>Loading…</div>
      ) : tab==="jobs" ? (
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead><tr><th>Job Title</th><th>Department</th><th>Type</th><th>Openings</th><th>Posted</th><th>Status</th>{canManage&&<th>Actions</th>}</tr></thead>
              <tbody>
                {jobs.map(j=>(
                  <tr key={j._id}>
                    <td style={{ fontWeight:600 }}>{j.title}</td>
                    <td><span className="badge badge-blue">{j.dept}</span></td>
                    <td style={{ color:"var(--text-secondary)" }}>{j.type}</td>
                    <td style={{ fontWeight:600 }}>{j.openings}</td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{j.postedDate?.slice(0,10)||j.createdAt?.slice(0,10)}</td>
                    <td>
                      {j.status==="Active" && <span className="badge badge-green">Active</span>}
                      {j.status==="Closed" && <span className="badge badge-gray">Closed</span>}
                      {j.status==="Paused" && <span className="badge badge-yellow">Paused</span>}
                    </td>
                    {canManage && (
                      <td>
                        <div style={{ display:"flex", gap:6 }}>
                          <button className="btn btn-ghost"  style={{ padding:"5px 10px", fontSize:12 }} onClick={()=>{ setJobForm({title:j.title,dept:j.dept,type:j.type,openings:j.openings,status:j.status}); setEditJobId(j._id); setShowJobModal(true); }}>Edit</button>
                          <button className="btn btn-danger" style={{ padding:"5px 10px", fontSize:12 }} onClick={()=>handleDeleteJob(j._id)}>Delete</button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
                {jobs.length===0 && <tr><td colSpan={canManage?7:6} style={{ textAlign:"center", color:"var(--text-muted)", padding:40 }}>No job postings yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead><tr><th>Candidate</th><th>Applied For</th><th>Applied On</th><th>Score</th><th>Stage</th>{canManage&&<th>Move Stage</th>}{canManage&&<th>Action</th>}</tr></thead>
              <tbody>
                {cands.map(c=>(
                  <tr key={c._id}>
                    <td>
                      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                        <div className="avatar" style={{ background:"#4f8bff22", color:"#4f8bff" }}>
                          {c.name?.slice(0,2).toUpperCase()}
                        </div>
                        <div>
                          <div style={{ fontWeight:600 }}>{c.name}</div>
                          {c.email && <div style={{ fontSize:12, color:"var(--text-secondary)" }}>{c.email}</div>}
                        </div>
                      </div>
                    </td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{c.job?.title || "—"}</td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{c.createdAt?.slice(0,10)}</td>
                    <td>
                      <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                        <span style={{ fontWeight:700, color:c.score>=85?"var(--accent-2)":c.score>=70?"var(--accent-4)":"var(--accent-3)" }}>{c.score||"—"}</span>
                      </div>
                    </td>
                    <td><span className={`badge ${stageColor(c.stage)}`}>{c.stage}</span></td>
                    {canManage && (
                      <td>
                        <select className="select" style={{ width:"auto", padding:"5px 10px", fontSize:12 }}
                          value={c.stage} onChange={e=>moveStage(c._id, e.target.value)}>
                          {stages.map(s=><option key={s}>{s}</option>)}
                        </select>
                      </td>
                    )}
                    {canManage && (
                      <td>
                        <button className="btn btn-danger" style={{ padding:"5px 10px", fontSize:12 }} onClick={()=>deleteCand(c._id)}>Remove</button>
                      </td>
                    )}
                  </tr>
                ))}
                {cands.length===0 && <tr><td colSpan={canManage?7:5} style={{ textAlign:"center", color:"var(--text-muted)", padding:40 }}>No candidates yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Job Modal */}
      {showJobModal && (
        <div className="modal-overlay" onClick={()=>setShowJobModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">{editJobId ? "Edit Job" : "Post New Job"}</h2>
              <button className="modal-close" onClick={()=>setShowJobModal(false)}>✕</button>
            </div>
            <div className="form-group"><label className="form-label">Job Title *</label><input className="input" placeholder="e.g. Frontend Developer" value={jobForm.title} onChange={fj("title")} /></div>
            <div className="form-row">
              <div className="form-group"><label className="form-label">Department</label><select className="select" value={jobForm.dept} onChange={fj("dept")}><option value="">Select</option>{DEPTS.map(d=><option key={d}>{d}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Type</label><select className="select" value={jobForm.type} onChange={fj("type")}>{["Full-Time","Part-Time","Contract","Internship"].map(t=><option key={t}>{t}</option>)}</select></div>
            </div>
            <div className="form-row">
              <div className="form-group"><label className="form-label">Openings</label><input className="input" type="number" min={1} value={jobForm.openings} onChange={fj("openings")} /></div>
              <div className="form-group"><label className="form-label">Status</label><select className="select" value={jobForm.status} onChange={fj("status")}>{["Active","Paused","Closed"].map(s=><option key={s}>{s}</option>)}</select></div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={()=>setShowJobModal(false)} disabled={saving}>Cancel</button>
              <button className="btn btn-primary" onClick={handleAddJob} disabled={saving||!jobForm.title}>{saving?"Saving…":editJobId?"Save Changes":"Post Job"}</button>
            </div>
          </div>
        </div>
      )}

      {/* Candidate Modal */}
      {showCandModal && (
        <div className="modal-overlay" onClick={()=>setShowCandModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">Add Candidate</h2>
              <button className="modal-close" onClick={()=>setShowCandModal(false)}>✕</button>
            </div>
            <div className="form-row">
              <div className="form-group"><label className="form-label">Full Name *</label><input className="input" placeholder="Candidate name" value={candForm.name} onChange={fc("name")} /></div>
              <div className="form-group"><label className="form-label">Email</label><input className="input" type="email" placeholder="email@example.com" value={candForm.email} onChange={fc("email")} /></div>
            </div>
            <div className="form-row">
              <div className="form-group"><label className="form-label">Job *</label>
                <select className="select" value={candForm.job} onChange={fc("job")}>
                  <option value="">Select job</option>
                  {jobs.filter(j=>j.status==="Active").map(j=><option key={j._id} value={j._id}>{j.title}</option>)}
                </select>
              </div>
              <div className="form-group"><label className="form-label">Stage</label>
                <select className="select" value={candForm.stage} onChange={fc("stage")}>
                  {stages.map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="form-row">
              <div className="form-group"><label className="form-label">Score (0–100)</label><input className="input" type="number" min={0} max={100} value={candForm.score} onChange={fc("score")} /></div>
              <div className="form-group"><label className="form-label">Phone</label><input className="input" placeholder="Phone number" value={candForm.phone} onChange={fc("phone")} /></div>
            </div>
            <div className="form-group"><label className="form-label">Notes</label><input className="input" placeholder="Any notes…" value={candForm.notes} onChange={fc("notes")} /></div>
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={()=>setShowCandModal(false)} disabled={saving}>Cancel</button>
              <button className="btn btn-primary" onClick={handleAddCand} disabled={saving||!candForm.name||!candForm.job}>{saving?"Saving…":"Add Candidate"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
