import { useState, useEffect } from "react";
import { employeeAPI, leaveAPI, recruitmentAPI, performanceAPI } from "./api";

const scoreColor = (s) => s>=90?"var(--accent-2)":s>=75?"var(--accent)":s>=60?"var(--accent-4)":"var(--accent-3)";

export default function Dashboard({ user }) {
  const [summary,    setSummary]    = useState(null);
  const [leaves,     setLeaves]     = useState([]);
  const [jobs,       setJobs]       = useState([]);
  const [reviews,    setReviews]    = useState([]);
  const [recentEmps, setRecentEmps] = useState([]);
  const [loading,    setLoading]    = useState(true);
  const now = new Date();
  const dateLabel = now.toLocaleDateString("en-IN", { month: "long", year: "numeric" });

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        // All four requests in parallel
        const [empData, leaveData, jobData, perfData, recentData] = await Promise.allSettled([
          employeeAPI.getSummary(),
          leaveAPI.getAll({ status: "Pending" }),
          recruitmentAPI.getJobs(),
          performanceAPI.getSummary(),
          employeeAPI.getAll({ limit: 4, sort: "-createdAt" }),
        ]);
        if (empData.status    === "fulfilled") setSummary(empData.value);
        if (leaveData.status  === "fulfilled") setLeaves(leaveData.value);
        if (jobData.status    === "fulfilled") setJobs(jobData.value);
        if (perfData.status   === "fulfilled") setReviews(perfData.value);
        if (recentData.status === "fulfilled") setRecentEmps(recentData.value.employees || []);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  // Employee self-view: only show their own panels
  const isEmployee = user?.role === "employee";

  const active      = summary?.active      ?? 0;
  const onLeave     = summary?.onLeave     ?? 0;
  const inactive    = summary?.inactive    ?? 0;
  const total       = summary?.total       ?? 0;
  const pending     = Array.isArray(leaves) ? leaves.filter(l => l.status === "Pending").length : 0;
  const openJobs    = jobs.filter(j => j.status === "Active").length;
  const totalApps   = jobs.reduce((s, j) => s + (j.applicants || 0), 0);
  const avgScore    = reviews?.avg ?? "—";

  // Dept breakdown from summary
  // byDept comes back as [{_id:"Engineering", count:3}, …]
  const depts  = summary?.byDept
    ? summary.byDept.map(d => [d._id, d.count]).sort((a,b) => b[1]-a[1])
    : [];
  const maxDep = depts[0]?.[1] || 1;

  if (loading) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:200, color:"var(--text-muted)", fontSize:15 }}>
      Loading dashboard…
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Welcome back, {user?.name} — here's what's happening today</p>
        </div>
        <div style={{ fontSize:13, color:"var(--text-muted)", textAlign:"right" }}>
          <div style={{ fontWeight:600, color:"var(--text-primary)" }}>{dateLabel}</div>
          <div>Live data</div>
        </div>
      </div>

      {!isEmployee && (
        <>
          <div className="stat-grid">
            {[
              { label:"Total Employees", value:total,   icon:"👥", color:"blue"   },
              { label:"Active",          value:active,  icon:"✅", color:"green"  },
              { label:"On Leave Today",  value:onLeave, icon:"🏖", color:"yellow" },
              { label:"Leave Requests",  value:pending, icon:"📋", color:"red"    },
            ].map(s => (
              <div className={`stat-card ${s.color}`} key={s.label}>
                <div className="stat-icon" style={{ background:"var(--bg-hover)" }}>{s.icon}</div>
                <div className="stat-value">{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="stat-grid" style={{ marginTop:0 }}>
            {[
              { label:"Open Positions",   value:openJobs,  icon:"🎯", color:"blue"   },
              { label:"Total Applicants", value:totalApps, icon:"📨", color:"green"  },
              { label:"Avg Perf Score",   value:avgScore,  icon:"⭐", color:"yellow" },
              { label:"Inactive Staff",   value:inactive,  icon:"⏸", color:"red"    },
            ].map(s => (
              <div className={`stat-card ${s.color}`} key={s.label}>
                <div className="stat-icon" style={{ background:"var(--bg-hover)" }}>{s.icon}</div>
                <div className="stat-value">{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>
        </>
      )}

      {isEmployee && (
        <div className="stat-grid">
          {[
            { label:"Your Leave Requests", value:leaves.length, icon:"📋", color:"blue"   },
            { label:"Pending Approval",    value:leaves.filter(l=>l.status==="Pending").length,  icon:"⏳", color:"yellow" },
            { label:"Approved Leaves",     value:leaves.filter(l=>l.status==="Approved").length, icon:"✅", color:"green"  },
            { label:"Rejected",            value:leaves.filter(l=>l.status==="Rejected").length, icon:"❌", color:"red"    },
          ].map(s => (
            <div className={`stat-card ${s.color}`} key={s.label}>
              <div className="stat-icon" style={{ background:"var(--bg-hover)" }}>{s.icon}</div>
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginTop:8 }}>

        {!isEmployee && depts.length > 0 && (
          <div className="card">
            <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>Headcount by Department</h3>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              {depts.map(([dept, count]) => (
                <div key={dept}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6, fontSize:13 }}>
                    <span style={{ fontWeight:600 }}>{dept}</span>
                    <span style={{ color:"var(--text-secondary)" }}>{count} employee{count !== 1 ? "s" : ""}</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width:`${(count/maxDep)*100}%`, background:"var(--accent)" }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="card">
          <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>
            {isEmployee ? "Your Leave History" : "Pending Leave Requests"}
          </h3>
          {leaves.filter(l => isEmployee ? true : l.status === "Pending").length === 0 ? (
            <p style={{ color:"var(--text-muted)", fontSize:14, textAlign:"center", padding:32 }}>
              {isEmployee ? "No leave applications yet 🎉" : "No pending requests 🎉"}
            </p>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {leaves.filter(l => isEmployee ? true : l.status === "Pending").slice(0, 5).map(l => (
                <div key={l._id} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 12px", background:"var(--bg-secondary)", borderRadius:10 }}>
                  <div>
                    <div style={{ fontWeight:600, fontSize:14 }}>{isEmployee ? l.type : l.employee?.name}</div>
                    <div style={{ fontSize:12, color:"var(--text-secondary)", marginTop:2 }}>
                      {l.type} · {l.from?.slice(0,10)} → {l.to?.slice(0,10)}
                    </div>
                  </div>
                  <span className={`badge ${l.status==="Approved"?"badge-green":l.status==="Pending"?"badge-yellow":"badge-red"}`}>{l.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {!isEmployee && recentEmps.length > 0 && (
          <div className="card">
            <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>Recent Employees</h3>
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {recentEmps.map(emp => (
                <div key={emp._id} style={{ display:"flex", alignItems:"center", gap:12, padding:"8px 0", borderBottom:"1px solid var(--border)" }}>
                  <div className="avatar" style={{ background:(emp.color||"#4f8bff")+"22", color:emp.color||"#4f8bff" }}>{emp.avatar}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:600, fontSize:14 }}>{emp.name}</div>
                    <div style={{ fontSize:12, color:"var(--text-secondary)" }}>{emp.dept} · Joined {emp.joined?.slice(0,10)}</div>
                  </div>
                  <span className={`badge ${emp.status==="Active"?"badge-green":emp.status==="On Leave"?"badge-yellow":"badge-gray"}`}>{emp.status}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {!isEmployee && jobs.filter(j=>j.status==="Active").length > 0 && (
          <div className="card" style={{ gridColumn:"1/-1" }}>
            <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>Active Job Openings</h3>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(240px, 1fr))", gap:14 }}>
              {jobs.filter(j=>j.status==="Active").map(j => (
                <div key={j._id} style={{ background:"var(--bg-secondary)", borderRadius:12, padding:"16px 18px" }}>
                  <div style={{ fontWeight:700, fontSize:14, marginBottom:4 }}>{j.title}</div>
                  <div style={{ fontSize:12, color:"var(--text-secondary)", marginBottom:12 }}>{j.dept}</div>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontSize:12, color:"var(--text-muted)" }}>👤 {j.applicants} applicants</span>
                    <span className="badge badge-green">Active</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
