import { useState, useEffect, useCallback } from "react";
import { performanceAPI, employeeAPI } from "./api";

const scoreColor = (s) => s>=90?"var(--accent-2)":s>=75?"var(--accent)":s>=60?"var(--accent-4)":"var(--accent-3)";
const ratingColor = (r) =>
  r==="Outstanding"?"badge-green":
  r==="Excellent"||r==="Very Good"?"badge-blue":
  r==="Good"?"badge-yellow":"badge-gray";

const RATINGS  = ["Average","Good","Very Good","Excellent","Outstanding"];
const PERIODS  = ["Q1 2025","Q2 2025","Q3 2025","Q4 2025","Q1 2026"];
const STATUSES = ["Pending","In Review","Completed"];

export default function Performance({ user }) {
  const [reviews,   setReviews]   = useState([]);
  const [summary,   setSummary]   = useState({});
  const [selected,  setSelected]  = useState(null);
  const [tab,       setTab]       = useState("reviews");
  const [period,    setPeriod]    = useState("Q1 2025");
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState("");
  const [saving,    setSaving]    = useState(false);
  const [employees, setEmployees] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const EMPTY_FORM = { employee:"", period, score:0, rating:"Good", goals:5, goalsmet:0, feedback:"" };
  const [form, setForm] = useState(EMPTY_FORM);

  const isEmployee = user?.role === "employee";
  const canManage  = ["admin","hr","manager"].includes(user?.role);

  const fetchData = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [reviewData, summaryData] = await Promise.all([
        performanceAPI.getAll(isEmployee ? {} : { period }),
        performanceAPI.getSummary(isEmployee ? {} : { period }),
      ]);
      setReviews(reviewData);
      setSummary(summaryData);
      if (canManage) {
        const empData = await employeeAPI.getAll({});
        setEmployees(empData.employees || []);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [period, isEmployee, canManage]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const updateStatus = async (id, status) => {
    setSaving(true);
    try {
      await performanceAPI.updateStatus(id, status);
      fetchData();
      if (selected?._id === id) setSelected({ ...selected, status });
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const handleCreate = async () => {
    setSaving(true);
    try {
      await performanceAPI.create(form);
      setShowModal(false); setForm(EMPTY_FORM);
      fetchData();
    } catch (err) { alert(err.message); }
    finally { setSaving(false); }
  };

  const f = field => e => setForm({ ...form, [field]: e.target.value });

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Performance</h1>
          <p className="page-subtitle">
            {isEmployee ? "Your performance reviews" : `${period} performance review cycle`}
          </p>
        </div>
        <div style={{ display:"flex", gap:10 }}>
          {!isEmployee && (
            <select className="select" style={{ width:"auto" }} value={period} onChange={e=>setPeriod(e.target.value)}>
              {PERIODS.map(p=><option key={p}>{p}</option>)}
            </select>
          )}
          {canManage && (
            <button className="btn btn-primary" onClick={()=>setShowModal(true)}>+ Add Review</button>
          )}
        </div>
      </div>

      <div className="stat-grid">
        {[
          { label:"Avg. Score",        value:summary.avg||"—",                     icon:"⭐", color:"blue"   },
          { label:"Reviews Completed", value:`${summary.completed||0}/${summary.total||0}`, icon:"✅", color:"green"  },
          { label:"Top Performer",     value:summary.top||"—",                     icon:"🏆", color:"yellow" },
          { label:"Pending Reviews",   value:summary.pending||0,                   icon:"⏳", color:"red"    },
        ].map(s=>(
          <div className={`stat-card ${s.color}`} key={s.label}>
            <div className="stat-icon" style={{ background:"var(--bg-hover)" }}>{s.icon}</div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      {error && <div className="auth-error" style={{ marginBottom:16 }}>{error}</div>}

      <div className="tabs">
        <button className={`tab ${tab==="reviews"?"active":""}`} onClick={()=>{ setTab("reviews"); setSelected(null); }}>Reviews</button>
        {!isEmployee && <button className={`tab ${tab==="skills"?"active":""}`} onClick={()=>setTab("skills")}>Skills Matrix</button>}
      </div>

      {tab==="reviews" && !selected && (
        <div className="card">
          {loading ? (
            <div style={{ textAlign:"center", padding:40, color:"var(--text-muted)" }}>Loading reviews…</div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Employee</th><th>Period</th><th>Score</th><th>Goals Met</th><th>Rating</th><th>Status</th><th>Details</th></tr>
                </thead>
                <tbody>
                  {reviews.map(r=>(
                    <tr key={r._id}>
                      <td>
                        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                          <div className="avatar" style={{ background:(r.employee?.color||"#4f8bff")+"22", color:r.employee?.color||"#4f8bff" }}>{r.employee?.avatar}</div>
                          <div>
                            <div style={{ fontWeight:600, fontSize:14 }}>{r.employee?.name}</div>
                            <div style={{ fontSize:12, color:"var(--text-secondary)" }}>{r.employee?.role}</div>
                          </div>
                        </div>
                      </td>
                      <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{r.period}</td>
                      <td>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          <span style={{ fontWeight:700, color:scoreColor(r.score), fontSize:16 }}>{r.score}</span>
                          <div className="progress-bar" style={{ width:60 }}>
                            <div className="progress-fill" style={{ width:`${r.score}%`, background:scoreColor(r.score) }}/>
                          </div>
                        </div>
                      </td>
                      <td style={{ fontWeight:600 }}>{r.goalsmet}/{r.goals}</td>
                      <td><span className={`badge ${ratingColor(r.rating)}`}>{r.rating}</span></td>
                      <td>
                        {r.status==="Completed" && <span className="badge badge-green">Completed</span>}
                        {r.status==="In Review" && <span className="badge badge-yellow">In Review</span>}
                        {r.status==="Pending"   && <span className="badge badge-gray">Pending</span>}
                      </td>
                      <td><button className="btn btn-ghost" style={{ padding:"5px 12px", fontSize:12 }} onClick={()=>setSelected(r)}>View →</button></td>
                    </tr>
                  ))}
                  {reviews.length===0 && (
                    <tr><td colSpan={7} style={{ textAlign:"center", color:"var(--text-muted)", padding:40 }}>No reviews found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab==="reviews" && selected && (
        <div>
          <button className="btn btn-ghost" style={{ marginBottom:16 }} onClick={()=>setSelected(null)}>← Back</button>
          <div className="card">
            <div style={{ display:"flex", alignItems:"center", gap:16, marginBottom:28 }}>
              <div className="avatar" style={{ background:(selected.employee?.color||"#4f8bff")+"22", color:selected.employee?.color||"#4f8bff", width:56, height:56, fontSize:20 }}>
                {selected.employee?.avatar}
              </div>
              <div>
                <div style={{ fontSize:20, fontWeight:700 }}>{selected.employee?.name}</div>
                <div style={{ color:"var(--text-secondary)", fontSize:14 }}>{selected.employee?.role} · {selected.employee?.dept}</div>
              </div>
              <div style={{ marginLeft:"auto", textAlign:"right" }}>
                <div style={{ fontSize:40, fontWeight:800, fontFamily:"Syne", color:scoreColor(selected.score) }}>{selected.score}</div>
                <span className={`badge ${ratingColor(selected.rating)}`}>{selected.rating}</span>
              </div>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginBottom:24 }}>
              {[
                { label:"Review Period",     value:selected.period },
                { label:"Reviewed By",       value:selected.reviewedBy?.name || "—" },
                { label:"Goals Assigned",    value:selected.goals },
                { label:"Goals Achieved",    value:selected.goalsmet },
              ].map(row=>(
                <div key={row.label} style={{ background:"var(--bg-secondary)", borderRadius:10, padding:"14px 16px" }}>
                  <div style={{ fontSize:12, color:"var(--text-secondary)", marginBottom:4 }}>{row.label}</div>
                  <div style={{ fontWeight:600 }}>{row.value}</div>
                </div>
              ))}
            </div>

            {selected.skills?.length > 0 && (
              <>
                <h4 style={{ fontWeight:700, marginBottom:14, fontSize:14 }}>Skill Ratings</h4>
                {selected.skills.map(sk=>(
                  <div key={sk.name} style={{ marginBottom:14 }}>
                    <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
                      <span style={{ fontSize:13 }}>{sk.name}</span>
                      <span style={{ fontSize:13, fontWeight:600, color:scoreColor(sk.score) }}>{sk.score}</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width:`${sk.score}%`, background:scoreColor(sk.score) }}/>
                    </div>
                  </div>
                ))}
              </>
            )}

            {selected.feedback && (
              <div style={{ marginTop:20 }}>
                <h4 style={{ fontWeight:700, marginBottom:10, fontSize:14 }}>Manager Feedback</h4>
                <p style={{ fontSize:14, color:"var(--text-secondary)", lineHeight:1.7, background:"var(--bg-secondary)", padding:"14px 16px", borderRadius:10 }}>{selected.feedback}</p>
              </div>
            )}

            {canManage && (
              <div style={{ marginTop:24, display:"flex", gap:10 }}>
                {selected.status==="Pending" && (
                  <button className="btn btn-primary" disabled={saving} onClick={()=>updateStatus(selected._id,"In Review")}>Start Review</button>
                )}
                {selected.status==="In Review" && (
                  <button className="btn btn-success" disabled={saving} onClick={()=>updateStatus(selected._id,"Completed")}>Mark Completed</button>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {tab==="skills" && !isEmployee && (
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Period</th>
                  <th>Score</th>
                  <th>Rating</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {reviews.map(r=>(
                  <tr key={r._id}>
                    <td style={{ fontWeight:600 }}>{r.employee?.name}</td>
                    <td style={{ color:"var(--text-secondary)", fontSize:13 }}>{r.period}</td>
                    <td>
                      <span style={{ fontWeight:700, color:scoreColor(r.score), fontSize:16 }}>{r.score}</span>
                    </td>
                    <td><span className={`badge ${ratingColor(r.rating)}`}>{r.rating}</span></td>
                    <td>
                      {r.status==="Completed" && <span className="badge badge-green">Completed</span>}
                      {r.status==="In Review" && <span className="badge badge-yellow">In Review</span>}
                      {r.status==="Pending"   && <span className="badge badge-gray">Pending</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && canManage && (
        <div className="modal-overlay" onClick={()=>setShowModal(false)}>
          <div className="modal" style={{ maxWidth:520 }} onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="modal-title">Add Performance Review</h2>
              <button className="modal-close" onClick={()=>setShowModal(false)}>✕</button>
            </div>
            <div className="form-group">
              <label className="form-label">Employee *</label>
              <select className="select" value={form.employee} onChange={f("employee")}>
                <option value="">Select employee</option>
                {employees.map(e=><option key={e._id} value={e._id}>{e.name} — {e.dept}</option>)}
              </select>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Period</label>
                <select className="select" value={form.period} onChange={f("period")}>
                  {PERIODS.map(p=><option key={p}>{p}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Rating</label>
                <select className="select" value={form.rating} onChange={f("rating")}>
                  {RATINGS.map(r=><option key={r}>{r}</option>)}
                </select>
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Score (0–100)</label>
                <input className="input" type="number" min={0} max={100} value={form.score} onChange={f("score")} />
              </div>
              <div className="form-group">
                <label className="form-label">Goals / Met</label>
                <div style={{ display:"flex", gap:8 }}>
                  <input className="input" type="number" min={0} placeholder="Total" value={form.goals} onChange={f("goals")} />
                  <input className="input" type="number" min={0} placeholder="Met"   value={form.goalsmet} onChange={f("goalsmet")} />
                </div>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Feedback</label>
              <input className="input" placeholder="Manager feedback…" value={form.feedback} onChange={f("feedback")} />
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost"   onClick={()=>setShowModal(false)} disabled={saving}>Cancel</button>
              <button className="btn btn-primary" onClick={handleCreate} disabled={saving||!form.employee}>{saving?"Saving…":"Add Review"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
