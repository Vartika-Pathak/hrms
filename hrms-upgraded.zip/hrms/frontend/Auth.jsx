import { useState } from "react";
import { authAPI } from "./api";

export default function Auth({ onLogin }) {
  const [mode, setMode]       = useState("login");   // "login" | "register"
  const [form, setForm]       = useState({ name: "", email: "", password: "", role: "hr" });
  const [error, setError]     = useState("");
  const [loading, setLoading] = useState(false);

  const f = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const handleSubmit = async () => {
    setError("");
    if (!form.email || !form.password) { setError("Email and password are required."); return; }
    setLoading(true);
    try {
      let data;
      if (mode === "login") {
        data = await authAPI.login({ email: form.email, password: form.password });
      } else {
        if (!form.name.trim()) { setError("Name is required."); setLoading(false); return; }
        if (form.password.length < 6) { setError("Password must be at least 6 characters."); setLoading(false); return; }
        data = await authAPI.register({ name: form.name, email: form.email, password: form.password, role: form.role });
      }
      // Store the JWT so api.js picks it up automatically on every future request
      localStorage.setItem("hrms_token", data.token);
      onLogin(data.user);
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-left">
        <div className="auth-brand">
          <div className="auth-logo">H</div>
          <span className="auth-logo-text">HRFlow</span>
        </div>
        <h1 className="auth-headline">Your people,<br />all in one place.</h1>
        <p className="auth-sub">Manage employees, payroll, attendance, recruitment, and performance — beautifully.</p>
        <div className="auth-features">
          {["👥 Employee Management","📅 Attendance Tracking","💰 Payroll Processing","🎯 Recruitment Pipeline","📈 Performance Reviews"].map(feat => (
            <div key={feat} className="auth-feature-pill">{feat}</div>
          ))}
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-card">
          <div className="auth-tabs">
            <button className={`auth-tab ${mode==="login"?"active":""}`}    onClick={() => { setMode("login");    setError(""); }}>Sign In</button>
            <button className={`auth-tab ${mode==="register"?"active":""}`} onClick={() => { setMode("register"); setError(""); }}>Register</button>
          </div>

          <h2 className="auth-card-title">
            {mode === "login" ? "Welcome back" : "Create account"}
          </h2>
          <p className="auth-card-sub">
            {mode === "login" ? "Sign in to your HRFlow workspace" : "Set up your HRFlow account"}
          </p>

          {mode === "register" && (
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input className="input" placeholder="e.g. Priya Nair" value={form.name} onChange={f("name")} />
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Email</label>
            <input className="input" type="email" placeholder="you@company.com" value={form.email} onChange={f("email")} onKeyDown={e => e.key === "Enter" && handleSubmit()} />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="input" type="password" placeholder={mode === "register" ? "Min. 6 characters" : "••••••••"} value={form.password} onChange={f("password")} onKeyDown={e => e.key === "Enter" && handleSubmit()} />
          </div>

          {mode === "register" && (
            <div className="form-group">
              <label className="form-label">Role</label>
              <select className="select" value={form.role} onChange={f("role")}>
                <option value="hr">HR Manager</option>
                <option value="manager">Manager</option>
                <option value="admin">Admin</option>
                <option value="employee">Employee</option>
              </select>
            </div>
          )}

          {error && <div className="auth-error">{error}</div>}

          <button className="btn btn-primary auth-submit" onClick={handleSubmit} disabled={loading}>
            {loading ? "Please wait…" : mode === "login" ? "Sign In" : "Create Account"}
          </button>

          {mode === "login" && (
            <p className="auth-card-sub" style={{ marginTop: 16, fontSize: 12, color: "var(--text-muted)" }}>
              Use your registered account credentials to sign in.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
