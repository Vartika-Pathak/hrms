import { useState, useEffect } from "react";
import Sidebar     from "./Sidebar";
import Dashboard   from "./Dashboard";
import Employees   from "./Employees";
import Attendance  from "./Attendance";
import Payroll     from "./Payroll";
import Recruitment from "./Recruitment";
import Performance from "./Performance";
import Auth        from "./Auth";
import "./App.css";

export default function App() {
  const [user,        setUser]        = useState(null);
  const [activePage,  setActivePage]  = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading,     setLoading]     = useState(true);

  useEffect(() => {
    const token     = localStorage.getItem("hrms_token");
    const savedUser = localStorage.getItem("hrms_user");
    if (token && savedUser) {
      try { setUser(JSON.parse(savedUser)); } catch { localStorage.removeItem("hrms_user"); }
    }
    setLoading(false);
  }, []);

  const handleLogin = (u) => {
    setUser(u);
    localStorage.setItem("hrms_user", JSON.stringify(u));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("hrms_token");
    localStorage.removeItem("hrms_user");
  };

  if (loading) return null;
  if (!user)   return <Auth onLogin={handleLogin} />;

  const isEmployee = user.role === "employee";

  // Role-based page visibility:
  // employees can only see dashboard, attendance (their own), payroll (own), performance (own)
  const pages = {
    dashboard:   <Dashboard   user={user} />,
    attendance:  <Attendance  user={user} />,
    payroll:     <Payroll     user={user} />,
    performance: <Performance user={user} />,
    ...(!isEmployee && {
      employees:   <Employees />,
      recruitment: <Recruitment user={user} />,
    }),
  };

  // If current page isn't allowed for this role, redirect to dashboard
  const safePage = pages[activePage] ? activePage : "dashboard";

  return (
    <div className={`app-shell ${sidebarOpen ? "sidebar-open" : "sidebar-closed"}`}>
      <Sidebar
        activePage={safePage}
        setActivePage={setActivePage}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        user={user}
        onLogout={handleLogout}
        isEmployee={isEmployee}
      />
      <main className="main-content">
        <div className="page-wrapper">{pages[safePage]}</div>
      </main>
    </div>
  );
}
