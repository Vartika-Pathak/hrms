/**
 * seed.js — Populate the database with demo data.
 * Usage: node seed.js
 * Will NOT overwrite existing data.
 */
require("dotenv").config();
const mongoose  = require("mongoose");
const bcrypt    = require("bcryptjs");
const connectDB = require("./config/db");

const User        = require("./models/User");
const Employee    = require("./models/Employee");
const Leave       = require("./models/Leave");
const Attendance  = require("./models/Attendance");
const Performance = require("./models/Performance");

const DEPARTMENTS = ["Engineering","Product","Design","HR","Finance","Marketing","Operations"];
const ROLES_EMP   = ["Software Engineer","Senior Engineer","Product Manager","Designer","HR Executive","Financial Analyst","Marketing Lead","DevOps Engineer"];
const NAMES       = ["Priya Nair","Arjun Sharma","Kavita Reddy","Rahul Mehta","Sunita Joshi","Amit Kumar","Deepa Pillai","Rohan Gupta","Anita Singh","Vikram Das","Meena Iyer","Suresh Patel"];
const LEAVE_TYPES = ["Sick Leave","Casual Leave","Earned Leave","WFH"];

const rand = (arr) => arr[Math.floor(Math.random() * arr.length)];
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

async function seed() {
  await connectDB();
  console.log("🌱 Seeding HRFlow demo data…\n");

  // ── Admin user ───────────────────────────────────────────────────
  const adminExists = await User.findOne({ email: "admin@hrflow.demo" });
  if (!adminExists) {
    await User.create({ name:"Admin User", email:"admin@hrflow.demo", password:"admin123", role:"admin" });
    console.log("✅ Admin user created  →  admin@hrflow.demo / admin123");
  } else {
    console.log("ℹ️  Admin user already exists, skipping.");
  }

  // ── HR user ──────────────────────────────────────────────────────
  const hrExists = await User.findOne({ email: "hr@hrflow.demo" });
  if (!hrExists) {
    await User.create({ name:"HR Manager", email:"hr@hrflow.demo", password:"hr12345", role:"hr" });
    console.log("✅ HR user created  →  hr@hrflow.demo / hr12345");
  }

  // ── Employees ────────────────────────────────────────────────────
  const existingCount = await Employee.countDocuments();
  if (existingCount < 5) {
    const created = [];
    for (const name of NAMES) {
      const dept  = rand(DEPARTMENTS);
      const role  = rand(ROLES_EMP);
      const email = name.toLowerCase().replace(/ /g, ".") + "@company.com";
      const emp   = await Employee.findOneAndUpdate(
        { email },
        {
          name, role, dept, email,
          phone:   `98${randInt(10000000,99999999)}`,
          status:  rand(["Active","Active","Active","On Leave"]),
          joined:  new Date(Date.now() - randInt(30, 730) * 86400000),
          salary:  randInt(40000, 150000),
          gender:  rand(["Male","Female","Other"]),
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
      created.push(emp);
    }
    console.log(`✅ ${created.length} employees seeded`);

    // Create User accounts for first 3 employees (role=employee)
    for (let i = 0; i < 3 && i < created.length; i++) {
      const emp = created[i];
      const userEmail = `emp${i+1}@hrflow.demo`;
      const userExists = await User.findOne({ email: userEmail });
      if (!userExists) {
        await User.create({ name: emp.name, email: userEmail, password: "emp12345", role: "employee", employeeId: emp._id });
        console.log(`✅ Employee login  →  ${userEmail} / emp12345  (${emp.name})`);
      }
    }

    // ── Leave records ────────────────────────────────────────────
    for (const emp of created.slice(0, 6)) {
      const from = new Date(Date.now() - randInt(1, 30) * 86400000);
      const to   = new Date(from.getTime() + randInt(0, 3) * 86400000);
      const days = Math.ceil((to - from) / 86400000) + 1;
      await Leave.findOneAndUpdate(
        { employee: emp._id, from },
        { employee: emp._id, type: rand(LEAVE_TYPES), from, to, days, reason: "Personal work", status: rand(["Pending","Approved","Rejected"]) },
        { upsert: true }
      );
    }
    console.log("✅ Sample leave records seeded");

    // ── Attendance this month ────────────────────────────────────
    const now = new Date();
    for (const emp of created) {
      for (let d = 1; d <= Math.min(now.getDate(), 20); d++) {
        const date = new Date(now.getFullYear(), now.getMonth(), d);
        if (date.getDay() === 0 || date.getDay() === 6) continue; // skip weekends
        await Attendance.findOneAndUpdate(
          { employee: emp._id, date },
          { employee: emp._id, date, status: rand(["Present","Present","Present","WFH","Absent"]), inTime: "09:15", outTime: "18:30" },
          { upsert: true }
        );
      }
    }
    console.log("✅ Attendance records seeded for this month");

    // ── Performance reviews ──────────────────────────────────────
    const periods = ["Q4 2024","Q1 2025"];
    for (const emp of created.slice(0, 8)) {
      for (const period of periods) {
        const score = randInt(60, 100);
        const rating = score >= 90 ? "Outstanding" : score >= 80 ? "Excellent" : score >= 70 ? "Very Good" : score >= 60 ? "Good" : "Average";
        await Performance.findOneAndUpdate(
          { employee: emp._id, period },
          { employee: emp._id, period, score, rating, goals: 5, goalsmet: randInt(3, 5), feedback: "Good progress this quarter.", status: "Completed" },
          { upsert: true }
        );
      }
    }
    console.log("✅ Performance reviews seeded");
  } else {
    console.log(`ℹ️  ${existingCount} employees already exist, skipping employee seed.`);
  }

  console.log("\n🎉 Seed complete!\n");
  console.log("Demo credentials:");
  console.log("  Admin:    admin@hrflow.demo / admin123");
  console.log("  HR:       hr@hrflow.demo / hr12345");
  console.log("  Employee: emp1@hrflow.demo / emp12345\n");
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
