const Employee = require("../models/Employee");

// Sensitive fields employees should never see for other people
const PUBLIC_FIELDS  = "name role dept email phone status joined avatar color employeeId";
const PRIVATE_FIELDS = "-pan -bank -emergency -notes"; // stripped when viewing others

// GET /api/employees
exports.getAll = async (req, res) => {
  try {
    // Employees cannot list all staff — they can only see their own record
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json({ total: 0, page: 1, employees: [] });
      const emp = await Employee.findById(req.user.employeeId);
      return res.json({ total: emp ? 1 : 0, page: 1, employees: emp ? [emp] : [] });
    }

    const { dept, status, search, page = 1, limit = 100 } = req.query;
    const filter = {};
    if (dept)   filter.dept   = dept;
    if (status) filter.status = status;
    if (search) filter.$or = [
      { name:  { $regex: search, $options: "i" } },
      { email: { $regex: search, $options: "i" } },
      { role:  { $regex: search, $options: "i" } },
    ];

    const total = await Employee.countDocuments(filter);

    // Managers see public fields only (no salary/PAN/bank)
    const projection = req.user.role === "manager" ? PUBLIC_FIELDS : "";

    const employees = await Employee.find(filter)
      .select(projection)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({ total, page: Number(page), employees });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/employees/:id
exports.getOne = async (req, res) => {
  try {
    const emp = await Employee.findById(req.params.id);
    if (!emp) return res.status(404).json({ error: "Employee not found" });

    // Employees can only view their own record
    if (req.user.role === "employee") {
      if (!req.user.employeeId || emp._id.toString() !== req.user.employeeId.toString())
        return res.status(403).json({ error: "Access denied" });
    }

    // Managers see stripped record (no salary/PAN/bank)
    if (req.user.role === "manager") {
      const { pan, bank, emergency, salary, ...safe } = emp.toObject();
      return res.json(safe);
    }

    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/employees  — HR/Admin only
exports.create = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR or Admin access required" });
    const emp = await Employee.create(req.body);
    res.status(201).json(emp);
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ error: "Email already exists" });
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/employees/:id  — HR/Admin only
exports.update = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR or Admin access required" });
    const emp = await Employee.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE /api/employees/:id  — Admin only
exports.remove = async (req, res) => {
  try {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Admin access required" });
    const emp = await Employee.findByIdAndDelete(req.params.id);
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json({ message: "Employee deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PATCH /api/employees/:id/status  — HR/Admin/Manager
exports.updateStatus = async (req, res) => {
  try {
    if (!["admin","hr","manager"].includes(req.user.role))
      return res.status(403).json({ error: "Manager or above access required" });
    const { status } = req.body;
    const emp = await Employee.findByIdAndUpdate(req.params.id, { status }, { new: true });
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PATCH /api/employees/:id/salary  — HR/Admin only
exports.updateSalary = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR or Admin access required" });
    const { salary } = req.body;
    const emp = await Employee.findByIdAndUpdate(req.params.id, { salary }, { new: true });
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/employees/stats/summary
exports.getSummary = async (req, res) => {
  try {
    // Employees get no org-wide summary
    if (req.user.role === "employee")
      return res.json({ total: 0, active: 0, onLeave: 0, inactive: 0, byDept: [] });

    const total    = await Employee.countDocuments();
    const active   = await Employee.countDocuments({ status: "Active" });
    const onLeave  = await Employee.countDocuments({ status: "On Leave" });
    const inactive = await Employee.countDocuments({ status: "Inactive" });
    const byDept   = await Employee.aggregate([
      { $group: { _id: "$dept", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);
    res.json({ total, active, onLeave, inactive, byDept });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
