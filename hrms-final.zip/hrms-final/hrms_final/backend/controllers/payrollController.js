const Payroll  = require("../models/Payroll");
const Employee = require("../models/Employee");
const User     = require("../models/User");
const { notify } = require("./notificationController");

// GET /api/payroll — employees see only their own, HR/admin see all
exports.getAll = async (req, res) => {
  try {
    const filter = {};

    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json([]);
      filter.employee = req.user.employeeId;
      // employees see all months for themselves
    } else {
      const { month, year, employee } = req.query;
      if (month)    filter.month    = month;
      if (year)     filter.year     = Number(year);
      if (employee) filter.employee = employee;
    }

    const records = await Payroll.find(filter)
      .populate("employee", "name dept avatar color salary")
      .sort({ year: -1, createdAt: -1 });

    // Employees see their own full record — that's fine (it's their data)
    // Managers see records but without tax details
    if (req.user.role === "manager") {
      const stripped = records.map(r => {
        const obj = r.toObject();
        delete obj.tax;
        return obj;
      });
      return res.json(stripped);
    }

    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/payroll/generate  — HR/admin only
exports.generate = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const { month, year } = req.body;
    const employees = await Employee.find({ status: "Active" });
    const created = [];
    for (const emp of employees) {
      const basic      = emp.salary;
      const hra        = Math.round(basic * 0.2);
      const ta         = 5000;
      const deductions = Math.round(basic * 0.1);
      const tax        = Math.round(basic * 0.05);
      try {
        const record = await Payroll.create({ employee: emp._id, month, year, basic, hra, ta, deductions, tax });
        created.push(record);
      } catch (e) {
        if (e.code !== 11000) throw e; // skip duplicates
      }
    }
    res.status(201).json({ message: `Generated payroll for ${created.length} employees`, created });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PATCH /api/payroll/:id/process  — HR/admin only
exports.process = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const record = await Payroll.findByIdAndUpdate(
      req.params.id,
      { status: "Processed", processedBy: req.user._id, processedAt: new Date() },
      { new: true }
    ).populate("employee", "name dept");
    if (!record) return res.status(404).json({ error: "Payroll record not found" });

    // Notify the employee
    await notifyPayroll(record.employee._id, record.month);

    res.json(record);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/payroll/process-all  — HR/admin only
exports.processAll = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const { month, year } = req.body;
    const result = await Payroll.updateMany(
      { month, year, status: "Pending" },
      { status: "Processed", processedBy: req.user._id, processedAt: new Date() }
    );

    // Notify all affected employees
    const processed = await Payroll.find({ month, year, status: "Processed" }).select("employee");
    for (const p of processed) {
      await notifyPayroll(p.employee, month);
    }

    res.json({ message: `Processed ${result.modifiedCount} payroll records` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/payroll/:id  — HR/admin only
exports.update = async (req, res) => {
  try {
    if (!["admin","hr"].includes(req.user.role))
      return res.status(403).json({ error: "HR/Admin access required" });
    const record = await Payroll.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!record) return res.status(404).json({ error: "Payroll record not found" });
    res.json(record);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Internal helper ──────────────────────────────────────────────────
const notifyPayroll = async (employeeObjectId, month) => {
  try {
    const user = await User.findOne({ employeeId: employeeObjectId }).select("_id");
    if (user) {
      await notify(user._id, {
        type: "payroll",
        title: "Payslip Ready",
        message: `Your payslip for ${month} has been processed.`,
        link: "payroll",
      });
    }
  } catch (err) {
    console.error("Payroll notify error:", err.message);
  }
};
