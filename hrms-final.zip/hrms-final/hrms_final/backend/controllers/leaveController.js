const Leave    = require("../models/Leave");
const Employee = require("../models/Employee");
const User     = require("../models/User");
const { notify } = require("./notificationController");

const isManagerUp = (u) => ["admin","hr","manager"].includes(u.role);

const adjustBalance = async (employeeObjectId, leaveType, days, op) => {
  const user = await User.findOne({ employeeId: employeeObjectId });
  if (!user) return;
  const bal = user.leaveBalance.find(b => b.type === leaveType);
  if (!bal) return;
  if (op === "pend")    bal.pending = (bal.pending || 0) + days;
  if (op === "unpend")  bal.pending = Math.max(0, (bal.pending || 0) - days);
  if (op === "deduct") { bal.used = (bal.used || 0) + days; bal.pending = Math.max(0, (bal.pending || 0) - days); }
  if (op === "restore") bal.used = Math.max(0, (bal.used || 0) - days);
  await user.save();
};

exports.getAll = async (req, res) => {
  try {
    const filter = {};
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.json([]);
      filter.employee = req.user.employeeId;
    } else {
      const { employee, status } = req.query;
      if (employee) filter.employee = employee;
      if (status)   filter.status   = status;
    }
    const leaves = await Leave.find(filter)
      .populate("employee", "name dept avatar color")
      .populate("approvedBy", "name")
      .sort({ createdAt: -1 });
    res.json(leaves);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.apply = async (req, res) => {
  try {
    let { employee, type, from, to, reason } = req.body;
    if (req.user.role === "employee") {
      if (!req.user.employeeId) return res.status(400).json({ error: "No employee profile linked to your account" });
      employee = req.user.employeeId;
    }
    const fromDate = new Date(from);
    const toDate   = new Date(to);
    const days     = Math.ceil((toDate - fromDate) / 86400000) + 1;

    if (req.user.role === "employee") {
      const user = await User.findById(req.user._id).select("leaveBalance");
      const bal  = user?.leaveBalance?.find(b => b.type === type);
      if (bal) {
        const available = bal.total - bal.used - (bal.pending || 0);
        if (days > available)
          return res.status(400).json({ error: `Insufficient ${type} balance. Available: ${available} days, requested: ${days} days` });
      }
    }

    const leave = await Leave.create({ employee, type, from: fromDate, to: toDate, days, reason });
    await leave.populate("employee", "name dept");
    await adjustBalance(employee, type, days, "pend");

    // Notify HR/admin users that a leave request was submitted
    const hrUsers = await User.find({ role: { $in: ["admin","hr"] } }).select("_id");
    const empName = leave.employee?.name || "An employee";
    for (const u of hrUsers) {
      await notify(u._id, {
        type: "leave",
        title: "New Leave Request",
        message: `${empName} applied for ${days}-day ${type} (${from} → ${to})`,
        link: "attendance",
      });
    }

    res.status(201).json(leave);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.updateStatus = async (req, res) => {
  try {
    if (!isManagerUp(req.user)) return res.status(403).json({ error: "Manager access required to approve/reject leaves" });
    const { status, remarks } = req.body;
    const prevLeave = await Leave.findById(req.params.id);
    if (!prevLeave) return res.status(404).json({ error: "Leave not found" });

    const leave = await Leave.findByIdAndUpdate(
      req.params.id,
      { status, remarks, approvedBy: req.user._id },
      { new: true }
    ).populate("employee", "name dept");

    if (status === "Approved" && prevLeave.status !== "Approved") {
      await adjustBalance(prevLeave.employee, prevLeave.type, prevLeave.days, "deduct");
      await Employee.findByIdAndUpdate(prevLeave.employee, { status: "On Leave" });
    } else if (status === "Rejected" && prevLeave.status === "Pending") {
      await adjustBalance(prevLeave.employee, prevLeave.type, prevLeave.days, "unpend");
    } else if (status === "Rejected" && prevLeave.status === "Approved") {
      await adjustBalance(prevLeave.employee, prevLeave.type, prevLeave.days, "restore");
    }

    // Notify the employee who applied
    const empUser = await User.findOne({ employeeId: prevLeave.employee });
    if (empUser) {
      await notify(empUser._id, {
        type: "leave",
        title: `Leave ${status}`,
        message: `Your ${prevLeave.type} request (${prevLeave.days} days) has been ${status.toLowerCase()}.${remarks ? " Remarks: " + remarks : ""}`,
        link: "attendance",
      });
    }

    res.json(leave);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.cancel = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) return res.status(404).json({ error: "Leave not found" });
    if (req.user.role === "employee") {
      if (!req.user.employeeId || leave.employee.toString() !== req.user.employeeId.toString())
        return res.status(403).json({ error: "You can only cancel your own leaves" });
      if (leave.status === "Approved")
        return res.status(400).json({ error: "Cannot cancel an approved leave. Contact HR." });
    }
    if (leave.status === "Pending")  await adjustBalance(leave.employee, leave.type, leave.days, "unpend");
    if (leave.status === "Approved") await adjustBalance(leave.employee, leave.type, leave.days, "restore");
    await Leave.findByIdAndDelete(req.params.id);
    res.json({ message: "Leave cancelled" });
  } catch (err) { res.status(500).json({ error: err.message }); }
};
