const express    = require("express");
const helmet     = require("helmet");
const rateLimit  = require("express-rate-limit");
const cors    = require("cors");
const dotenv  = require("dotenv");
const connectDB = require("./config/db");

dotenv.config();
connectDB();

const app = express();

app.use(cors({ origin: ["http://localhost:3000", "http://localhost:5173"], credentials: true }));
// Security headers
app.use(helmet({ crossOriginResourcePolicy: false }));

// Rate limiting — 200 req/15min per IP
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, message: { error: "Too many requests, slow down." } });
app.use("/api/", limiter);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

if (process.env.NODE_ENV === "development") {
  app.use((req, _res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
  });
}

// Routes
app.use("/api/auth",        require("./routes/auth"));
app.use("/api/employees",   require("./routes/employees"));
app.use("/api/attendance",  require("./routes/attendance"));
app.use("/api/payroll",     require("./routes/payroll"));
app.use("/api/recruitment", require("./routes/recruitment"));
app.use("/api/performance", require("./routes/performance"));
app.use("/api/leaves",      require("./routes/leaves"));

app.use("/api/notifications", require("./routes/notifications"));

app.get("/api/health", (_req, res) =>
  res.json({ status: "ok", message: "HRFlow API is running" })
);

app.use((_req, res) => res.status(404).json({ error: "Route not found" }));

app.use((err, _req, res, _next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ error: err.message || "Internal server error" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`HRFlow API running on http://localhost:${PORT}`));
