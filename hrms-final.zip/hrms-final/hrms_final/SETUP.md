# HRFlow HRMS — Final Setup Guide

## What's in this build

**Frontend** (React + Vite) — 16 files
**Backend** (Node.js + Express + MongoDB) — 32 files

---

## Changes in this version

### Backend fixes
| File | What changed |
|---|---|
| `controllers/employeeController.js` | **RBAC**: Employees only see their own record. Managers see public fields only (no salary/PAN/bank). Only HR/Admin can create, edit, delete employees. |
| `controllers/payrollController.js` | **RBAC**: Employees see only their own payslips. Managers see records without tax detail. `process` and `processAll` now trigger push notifications to employees. |
| `controllers/leaveController.js` | **Leave balance**: Applying marks balance as `pending`. Approving deducts from `used`. Rejecting/cancelling restores balance. Employees blocked if insufficient balance. Sends notifications on apply and on approval/rejection. |
| `models/User.js` | Leave balance stored per user with `total`, `used`, `pending` per leave type. |

### Frontend fixes
| File | What changed |
|---|---|
| `Leave.jsx` | HR/managers now see an employee selector when applying on behalf. All API calls properly wired. Balance cards show for employees. |
| `Employees.jsx` | Salary column hidden for manager role. |
| `EmployeeDetail.jsx` | PAN, Bank Account, and Salary hidden for manager role — shows "Confidential". |
| `App.jsx` | Passes `user` prop to `Employees`. |

### Already wired (unchanged)
All 6 pages (Dashboard, Attendance, Leave, Payroll, Performance, Recruitment) pull live data from the backend API. Notifications bell in sidebar polls every 30s.

---

## Role permissions summary

| Feature | Admin | HR | Manager | Employee |
|---|---|---|---|---|
| View all employees | ✅ | ✅ | ✅ (no salary/PAN/bank) | ❌ (own only) |
| Create/edit employees | ✅ | ✅ | ❌ | ❌ |
| Delete employees | ✅ | ❌ | ❌ | ❌ |
| View all payroll | ✅ | ✅ | ✅ (no tax) | ❌ (own only) |
| Generate/process payroll | ✅ | ✅ | ❌ | ❌ |
| Approve/reject leaves | ✅ | ✅ | ✅ | ❌ |
| Apply leave for others | ✅ | ✅ | ✅ | ❌ |
| View all leave requests | ✅ | ✅ | ✅ | ❌ (own only) |
| Add/manage recruitment | ✅ | ✅ | ❌ | ❌ |
| Add performance reviews | ✅ | ✅ | ✅ | ❌ |

---

## Setup

### 1. MongoDB
Create a free cluster at [cloud.mongodb.com](https://cloud.mongodb.com) → get the connection string.

### 2. Backend
```bash
cd backend
cp .env.example .env
# Edit .env:
#   MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/hrms
#   JWT_SECRET=any-long-random-string
#   PORT=5000

npm install
npm run seed    # creates demo users + sample data
npm run dev     # starts on http://localhost:5000
```

### 3. Frontend
```bash
cd frontend
npm install
# Optional: create .env.local with VITE_API_URL=http://localhost:5000/api
npm run dev     # starts on http://localhost:5173
```

### 4. Demo credentials (after seed)
| Role | Email | Password |
|---|---|---|
| Admin | admin@hrflow.demo | admin123 |
| HR | hr@hrflow.demo | hr12345 |
| Employee | emp1@hrflow.demo | emp12345 |
| Employee | emp2@hrflow.demo | emp12345 |
| Employee | emp3@hrflow.demo | emp12345 |

---

## How leave balance works

1. Employee applies → days marked as `pending` in their balance
2. HR approves → days moved from `pending` to `used`, employee status set to "On Leave", notification sent
3. HR rejects → `pending` days restored, notification sent
4. Employee cancels pending leave → `pending` days restored
5. Balance visible on the Leave page as balance cards and in the apply form

