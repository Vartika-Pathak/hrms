import { useState, useEffect, useCallback } from "react";
import { leaveAPI, authAPI, employeeAPI } from "./api";

const TYPE_COLORS = {
  "Sick Leave":      "#ff6b6b",
  "Casual Leave":    "#4f8bff",
  "Earned Leave":    "#00d4b4",
  "WFH":             "#a78bfa",
  "Maternity Leave": "#ffc94a",
  "Paternity Leave": "#4f8bff",
};
const LEAVE_TYPES = ["Sick Leave","Casual Leave","Earned Leave","WFH","Maternity Leave","Paternity Leave"];

export default function Leave({ user }) {
  const [leaves,       setLeaves]       = useState([]);
  const [balance,      setBalance]      = useState([]);
  const [employees,    setEmployees]    = useState([]); // for HR/manager apply on behalf
  const [loading,      setLoading]      = useState(true);
  const [saving,       setSaving]       = useState(false);
  const [error,        setError]        = useState("");
  const [success,      setSuccess]      = useState("");
  const [showForm,     setShowForm]     = useState(false);
  const [filterStatus, setFilterStatus] = useState("All");

  const EMPTY = { type: "Sick Leave", from: "", to: "", reason: "", employee: "" };
  const [form, setForm] = useState(EMPTY);

  const isEmployee = user?.role === "employee";
  const canManage  = ["admin","hr","manager"].includes(user?.role);

  const fetchData = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const calls = [leaveAPI.getAll({})];
      if (isEmployee) calls.push(authAPI.getLeaveBalance());
      if (canManage)  calls.push(employeeAPI.getAll({ limit: 200 }));

      const results = await Promise.allSettled(calls);

      if (results[0].status === "fulfilled") setLeaves(results[0].value);
      if (isEmployee && results[1]?.status === "fulfilled")
        setBalance(results[1].value.leaveBalance || []);
      if (canManage) {
        const empIdx = isEmployee ? 2 : 1;
        if (results[empIdx]?.status === "fulfilled")
          setEmployees(results[empIdx].value.employees || []);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [isEmployee, canManage]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const f = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const calcDays = () => {
    if (!form.from || !form.to) return 0;
    return Math.max(0, Math.ceil((new Date(form.to) - new Date(form.from)) / 86400000) + 1);
  };

  const handleApply = async () => {
    if (!form.from || !form.to || !form.reason.trim()) { setError("All fields are required."); return; }
    if (new Date(form.to) < new Date(form.from)) { setError("End date must be after start date."); return; }
    if (canManage && !form.employee) { setError("Please select an employee."); return; }
    setSaving(true); setError(""); setSuccess("");
    try {
      // For HR/manager: pass employee id. For employee: backend uses req.user.employeeId
      const payload = { type: form.type, from: form.from, to: form.to, reason: form.reason };
      if (canManage) payload.employee = form.employee;
      await leaveAPI.apply(payload);
      setSuccess("Leave application submitted successfully!");
      setShowForm(false);
      setForm(EMPTY);
      fetchData();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateStatus = async (id, status) => {
    setSaving(true); setError(""); setSuccess("");
    try {
      await leaveAPI.updateStatus(id, status);
      setSuccess(`Leave ${status.toLowerCase()} successfully.`);
      fetchData();
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };

  const handleCancel = async (id) => {
    if (!confirm("Cancel this leave application?")) return;
    setSaving(true); setError(""); setSuccess("");
    try {
      await leaveAPI.cancel(id);
      setSuccess("Leave cancelled.");
      fetchData();
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };

  const filtered = filterStatus === "All" ? leaves : leaves.filter(l => l.status === filterStatus);
  const days = calcDays();
  const selBal = balance.find(b => b.type === form.type);
  const available = selBal ? selBal.total - selBal.used - (selBal.pending || 0) : null;

  if (loading) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:200, color:"var(--text-muted)", fontSize:15 }}>
      Loading leave data…
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Leave Management</h1>
          <p className="page-subtitle">
            {isEmployee ? "Apply for leave and track your applications" : "Review and manage team leave requests"}
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => { setShowForm(!showForm); setError(""); setSuccess(""); }}>
          {showForm ? "✕ Cancel" : isEmployee ? "+ Apply for Leave" : "+ Apply on Behalf"}
        </button>
      </div>

      {(error || success) && (
        <div style={{ marginBottom:16, padding:"12px 16px", borderRadius:10, background: error ? "rgba(255,107,107,0.12)" : "rgba(0,212,180,0.12)", border:`1px solid ${error ? "#ff6b6b44" : "#00d4b444"}`, color: error ? "#ff6b6b" : "#00d4b4", fontSize:14 }}>
          {error || success}
        </div>
      )}

      {/* Apply Form */}
      {showForm && (
        <div className="card" style={{ marginBottom:24 }}>
          <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>
            {isEmployee ? "New Leave Application" : "Apply Leave on Behalf of Employee"}
          </h3>
          <div style={{ display:"grid", gridTemplateColumns: canManage ? "1fr 1fr 1fr 1fr" : "1fr 1fr 1fr", gap:16, marginBottom:16 }}>
            {canManage && (
              <div className="form-group">
                <label className="form-label">Employee *</label>
                <select className="select" value={form.employee} onChange={f("employee")}>
                  <option value="">Select employee</option>
                  {employees.map(e => <option key={e._id} value={e._id}>{e.name} — {e.dept}</option>)}
                </select>
              </div>
            )}
            <div className="form-group">
              <label className="form-label">Leave Type</label>
              <select className="select" value={form.type} onChange={f("type")}>
                {LEAVE_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">From</label>
              <input className="input" type="date" value={form.from} onChange={f("from")} min={new Date().toISOString().slice(0,10)} />
            </div>
            <div className="form-group">
              <label className="form-label">To</label>
              <input className="input" type="date" value={form.to} onChange={f("to")} min={form.from || new Date().toISOString().slice(0,10)} />
            </div>
          </div>
          {days > 0 && (
            <div style={{ marginBottom:12, fontSize:13, color:"var(--accent-2)" }}>
              📅 Duration: <strong>{days} day{days !== 1 ? "s" : ""}</strong>
              {isEmployee && available !== null && (
                <span style={{ marginLeft:12, color: days > available ? "var(--accent-3)" : "var(--text-secondary)" }}>
                  · Available: {available} days
                </span>
              )}
            </div>
          )}
          <div className="form-group" style={{ marginBottom:16 }}>
            <label className="form-label">Reason</label>
            <textarea className="input" rows={3} style={{ resize:"vertical" }} placeholder="Brief reason for leave…" value={form.reason} onChange={f("reason")} />
          </div>
          <div style={{ display:"flex", gap:12 }}>
            <button className="btn btn-primary" onClick={handleApply} disabled={saving || (isEmployee && available === 0)}>
              {saving ? "Submitting…" : "Submit Application"}
            </button>
            <button className="btn btn-ghost" onClick={() => { setShowForm(false); setForm(EMPTY); setError(""); }}>Cancel</button>
          </div>
        </div>
      )}

      {/* Balance Cards — employee only */}
      {isEmployee && balance.length > 0 && (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(160px, 1fr))", gap:14, marginBottom:24 }}>
          {balance.map(b => {
            const avail = b.total - b.used - (b.pending || 0);
            const pct = Math.max(0, Math.min(100, (avail / b.total) * 100));
            return (
              <div key={b.type} className="card" style={{ padding:"16px 18px" }}>
                <div style={{ fontSize:12, color:"var(--text-secondary)", marginBottom:6 }}>{b.type}</div>
                <div style={{ fontSize:24, fontWeight:800, fontFamily:"Syne", color: TYPE_COLORS[b.type] || "var(--accent)" }}>
                  {avail}
                </div>
                <div style={{ fontSize:11, color:"var(--text-muted)", marginBottom:10 }}>of {b.total} available</div>
                <div style={{ height:4, background:"var(--border)", borderRadius:4 }}>
                  <div style={{ width:`${pct}%`, height:"100%", background: TYPE_COLORS[b.type] || "var(--accent)", borderRadius:4, transition:"width 0.3s" }} />
                </div>
                {b.pending > 0 && <div style={{ fontSize:11, color:"var(--accent-4)", marginTop:6 }}>⏳ {b.pending} pending</div>}
              </div>
            );
          })}
        </div>
      )}

      {/* Filters */}
      <div style={{ display:"flex", gap:8, marginBottom:20 }}>
        {["All","Pending","Approved","Rejected"].map(s => (
          <button key={s} onClick={() => setFilterStatus(s)}
            style={{ padding:"6px 14px", borderRadius:8, border:`1px solid ${filterStatus===s?"var(--accent)":"var(--border)"}`, background: filterStatus===s?"var(--accent-soft)":"transparent", color: filterStatus===s?"var(--accent)":"var(--text-secondary)", fontSize:13, cursor:"pointer" }}>
            {s}
            <span style={{ marginLeft:6, background:"var(--bg-hover)", padding:"1px 7px", borderRadius:10, fontSize:11 }}>
              {s==="All" ? leaves.length : leaves.filter(l=>l.status===s).length}
            </span>
          </button>
        ))}
      </div>

      {/* Leave cards */}
      {filtered.length === 0 ? (
        <div style={{ textAlign:"center", padding:60, color:"var(--text-muted)", fontSize:15 }}>
          No {filterStatus !== "All" ? filterStatus.toLowerCase() + " " : ""}leave records found
        </div>
      ) : (
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          {filtered.map(l => (
            <div key={l._id} className="card" style={{ padding:"16px 20px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                <div style={{ display:"flex", gap:14, alignItems:"flex-start" }}>
                  <div style={{ width:38, height:38, borderRadius:10, background:(TYPE_COLORS[l.type]||"#4f8bff")+"22", display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>
                    {l.type==="WFH"?"🏠":l.type==="Sick Leave"?"🤒":l.type==="Casual Leave"?"🌴":l.type==="Earned Leave"?"⭐":l.type==="Maternity Leave"?"👶":"🎉"}
                  </div>
                  <div>
                    {!isEmployee && l.employee && (
                      <div style={{ fontWeight:700, fontSize:14, marginBottom:2 }}>
                        {l.employee.name}
                        <span style={{ fontWeight:400, color:"var(--text-secondary)", marginLeft:8, fontSize:13 }}>{l.employee.dept}</span>
                      </div>
                    )}
                    <div style={{ fontWeight:isEmployee?700:600, fontSize:isEmployee?15:13 }}>{l.type}</div>
                    <div style={{ fontSize:12, color:"var(--text-secondary)", marginTop:3 }}>
                      {new Date(l.from).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"})}
                      {" → "}
                      {new Date(l.to).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"})}
                      <span style={{ marginLeft:10, color:"var(--text-muted)" }}>({l.days} day{l.days!==1?"s":""})</span>
                    </div>
                    <div style={{ fontSize:12, color:"var(--text-muted)", marginTop:4, maxWidth:480 }}>{l.reason}</div>
                    {l.remarks && <div style={{ fontSize:12, marginTop:4, color:"var(--accent-4)" }}>Remarks: {l.remarks}</div>}
                  </div>
                </div>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:8 }}>
                  <span className={`badge ${l.status==="Approved"?"badge-green":l.status==="Pending"?"badge-yellow":"badge-red"}`}>
                    {l.status}
                  </span>
                  <div style={{ display:"flex", gap:8 }}>
                    {canManage && l.status === "Pending" && (
                      <>
                        <button className="btn btn-primary" style={{ padding:"4px 12px", fontSize:12 }} onClick={() => handleUpdateStatus(l._id, "Approved")} disabled={saving}>Approve</button>
                        <button className="btn btn-ghost"   style={{ padding:"4px 12px", fontSize:12, color:"var(--accent-3)" }} onClick={() => handleUpdateStatus(l._id, "Rejected")} disabled={saving}>Reject</button>
                      </>
                    )}
                    {isEmployee && l.status === "Pending" && (
                      <button className="btn btn-ghost" style={{ padding:"4px 12px", fontSize:12, color:"var(--accent-3)" }} onClick={() => handleCancel(l._id)} disabled={saving}>Cancel</button>
                    )}
                  </div>
                  <div style={{ fontSize:11, color:"var(--text-muted)" }}>
                    {new Date(l.createdAt).toLocaleDateString("en-IN",{day:"numeric",month:"short"})}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
