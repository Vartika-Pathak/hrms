import { useState } from "react";
import { authAPI } from "./api";

export default function Profile({ user, onUserUpdate }) {
  const [tab,     setTab]     = useState("info");
  const [saving,  setSaving]  = useState(false);
  const [error,   setError]   = useState("");
  const [success, setSuccess] = useState("");
  const [pwForm,  setPwForm]  = useState({ currentPassword:"", newPassword:"", confirm:"" });

  const initials = user?.name?.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase() || "U";
  const roleLabel = { admin:"Administrator", hr:"HR Manager", manager:"Manager", employee:"Employee" };

  const pf = (field) => (e) => setPwForm({ ...pwForm, [field]: e.target.value });

  const handleChangePassword = async () => {
    setError(""); setSuccess("");
    if (!pwForm.currentPassword || !pwForm.newPassword) { setError("All fields are required."); return; }
    if (pwForm.newPassword.length < 6) { setError("New password must be at least 6 characters."); return; }
    if (pwForm.newPassword !== pwForm.confirm) { setError("New passwords do not match."); return; }
    setSaving(true);
    try {
      await authAPI.changePassword({ currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
      setSuccess("Password changed successfully!");
      setPwForm({ currentPassword:"", newPassword:"", confirm:"" });
    } catch (err) {
      setError(err.message);
    } finally { setSaving(false); }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">My Profile</h1>
          <p className="page-subtitle">Your account information and settings</p>
        </div>
      </div>

      {/* Avatar + summary */}
      <div className="card" style={{ marginBottom:24, display:"flex", alignItems:"center", gap:24 }}>
        <div style={{ width:72, height:72, borderRadius:20, background:"linear-gradient(135deg,#4f8bff,#00d4b4)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:26, fontWeight:700, color:"#fff", fontFamily:"Syne", flexShrink:0 }}>
          {initials}
        </div>
        <div>
          <div style={{ fontFamily:"Syne", fontWeight:800, fontSize:22 }}>{user?.name}</div>
          <div style={{ color:"var(--text-secondary)", marginTop:4, fontSize:14 }}>{user?.email}</div>
          <span className="badge badge-blue" style={{ marginTop:8, display:"inline-block" }}>{roleLabel[user?.role] || user?.role}</span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", gap:4, marginBottom:24, borderBottom:"1px solid var(--border)", paddingBottom:0 }}>
        {["info","password"].map(t => (
          <button key={t} onClick={() => { setTab(t); setError(""); setSuccess(""); }}
            style={{ padding:"8px 20px", background:"transparent", border:"none", borderBottom:`2px solid ${tab===t?"var(--accent)":"transparent"}`, color:tab===t?"var(--accent)":"var(--text-secondary)", fontSize:14, fontWeight:600, cursor:"pointer", marginBottom:-1, transition:"all 0.2s" }}>
            {t === "info" ? "Account Info" : "Change Password"}
          </button>
        ))}
      </div>

      {(error || success) && (
        <div style={{ marginBottom:16, padding:"12px 16px", borderRadius:10, background: error ? "rgba(255,107,107,0.12)" : "rgba(0,212,180,0.12)", border:`1px solid ${error ? "#ff6b6b44" : "#00d4b444"}`, color: error ? "#ff6b6b" : "#00d4b4", fontSize:14 }}>
          {error || success}
        </div>
      )}

      {tab === "info" && (
        <div className="card" style={{ maxWidth:520 }}>
          <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>Account Details</h3>
          <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
            {[
              { label:"Full Name",   value: user?.name },
              { label:"Email",       value: user?.email },
              { label:"Role",        value: roleLabel[user?.role] || user?.role },
              { label:"User ID",     value: user?.id || user?._id },
            ].map(row => (
              <div key={row.label} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"12px 0", borderBottom:"1px solid var(--border)" }}>
                <span style={{ fontSize:13, color:"var(--text-secondary)" }}>{row.label}</span>
                <span style={{ fontSize:14, fontWeight:600, color:"var(--text-primary)" }}>{row.value || "—"}</span>
              </div>
            ))}
          </div>
          <p style={{ marginTop:20, fontSize:12, color:"var(--text-muted)" }}>
            To update your name or email, contact an administrator.
          </p>
        </div>
      )}

      {tab === "password" && (
        <div className="card" style={{ maxWidth:420 }}>
          <h3 style={{ fontFamily:"Syne", fontWeight:700, fontSize:15, marginBottom:20 }}>Change Password</h3>
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            <div className="form-group">
              <label className="form-label">Current Password</label>
              <input className="input" type="password" placeholder="••••••••" value={pwForm.currentPassword} onChange={pf("currentPassword")} />
            </div>
            <div className="form-group">
              <label className="form-label">New Password</label>
              <input className="input" type="password" placeholder="Min. 6 characters" value={pwForm.newPassword} onChange={pf("newPassword")} />
            </div>
            <div className="form-group">
              <label className="form-label">Confirm New Password</label>
              <input className="input" type="password" placeholder="Repeat new password" value={pwForm.confirm} onChange={pf("confirm")} />
            </div>
            <button className="btn btn-primary" onClick={handleChangePassword} disabled={saving} style={{ marginTop:4 }}>
              {saving ? "Updating…" : "Update Password"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
