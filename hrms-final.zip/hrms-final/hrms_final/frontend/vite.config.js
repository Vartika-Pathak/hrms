import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Only proxy backend API routes, not frontend module requests like /api.js
      "/api/": { target: "http://localhost:5000", changeOrigin: true },
    },
  },
});
