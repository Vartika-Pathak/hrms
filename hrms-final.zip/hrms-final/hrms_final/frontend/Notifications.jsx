import { useState, useEffect, useRef, useCallback } from "react";
import { notificationAPI } from "./api";

const typeIcon = { leave:"📋", payroll:"💰", performance:"📈", attendance:"📅", system:"🔔" };

export default function Notifications() {
  const [open,          setOpen]          = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unread,        setUnread]        = useState(0);
  const ref = useRef(null);

  const fetch = useCallback(async () => {
    try {
      const data = await notificationAPI.getAll();
      setNotifications(data.notifications || []);
      setUnread(data.unread || 0);
    } catch { /* silently fail — non-critical */ }
  }, []);

  useEffect(() => {
    fetch();
    const interval = setInterval(fetch, 30000); // poll every 30s
    return () => clearInterval(interval);
  }, [fetch]);

  // Close on outside click
  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const markRead = async (id) => {
    try {
      await notificationAPI.markRead(id);
      setNotifications(prev => prev.map(n => n._id === id ? { ...n, read: true } : n));
      setUnread(prev => Math.max(0, prev - 1));
    } catch { /* silent */ }
  };

  const markAll = async () => {
    try {
      await notificationAPI.markAllRead();
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnread(0);
    } catch { /* silent */ }
  };

  const remove = async (id, e) => {
    e.stopPropagation();
    try {
      await notificationAPI.remove(id);
      setNotifications(prev => prev.filter(n => n._id !== id));
      setUnread(prev => {
        const wasUnread = notifications.find(n => n._id === id && !n.read);
        return wasUnread ? Math.max(0, prev - 1) : prev;
      });
    } catch { /* silent */ }
  };

  return (
    <div ref={ref} style={{ position:"relative" }}>
      <button
        onClick={() => { setOpen(!open); if (!open) fetch(); }}
        style={{ position:"relative", width:36, height:36, borderRadius:10, border:"1px solid var(--border)", background:"var(--bg-secondary)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}
        title="Notifications"
      >
        🔔
        {unread > 0 && (
          <span style={{ position:"absolute", top:-4, right:-4, minWidth:18, height:18, borderRadius:10, background:"var(--accent-3)", color:"#fff", fontSize:10, fontWeight:700, display:"flex", alignItems:"center", justifyContent:"center", padding:"0 4px", border:"2px solid var(--bg-primary)" }}>
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div style={{ position:"absolute", top:44, right:0, width:"min(360px, calc(100vw - 48px))", maxHeight:480, background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:14, boxShadow:"var(--shadow)", zIndex:9999, display:"flex", flexDirection:"column", overflow:"hidden" }}>
          <div style={{ padding:"14px 16px", borderBottom:"1px solid var(--border)", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontFamily:"Syne", fontWeight:700, fontSize:14 }}>Notifications {unread > 0 && <span style={{ fontSize:12, color:"var(--accent)", marginLeft:6 }}>{unread} new</span>}</span>
            {unread > 0 && (
              <button onClick={markAll} style={{ fontSize:12, color:"var(--accent)", background:"none", border:"none", cursor:"pointer" }}>Mark all read</button>
            )}
          </div>

          <div style={{ overflowY:"auto", flex:1 }}>
            {notifications.length === 0 ? (
              <div style={{ padding:40, textAlign:"center", color:"var(--text-muted)", fontSize:13 }}>
                <div style={{ fontSize:32, marginBottom:10 }}>🔕</div>
                You're all caught up!
              </div>
            ) : (
              notifications.map(n => (
                <div key={n._id}
                  onClick={() => !n.read && markRead(n._id)}
                  style={{ padding:"12px 16px", borderBottom:"1px solid var(--border)", display:"flex", gap:12, cursor: n.read ? "default" : "pointer", background: n.read ? "transparent" : "var(--accent-soft)", transition:"background 0.2s" }}
                >
                  <span style={{ fontSize:20, flexShrink:0 }}>{typeIcon[n.type] || "🔔"}</span>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontWeight:n.read?500:700, fontSize:13, marginBottom:2 }}>{n.title}</div>
                    <div style={{ fontSize:12, color:"var(--text-secondary)", lineHeight:1.4 }}>{n.message}</div>
                    <div style={{ fontSize:11, color:"var(--text-muted)", marginTop:4 }}>
                      {new Date(n.createdAt).toLocaleDateString("en-IN",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"})}
                    </div>
                  </div>
                  <button onClick={(e) => remove(n._id, e)} style={{ background:"none", border:"none", color:"var(--text-muted)", cursor:"pointer", fontSize:14, flexShrink:0, alignSelf:"flex-start", padding:"0 2px" }}>✕</button>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
