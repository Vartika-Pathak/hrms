import Notifications from "./Notifications";
import "./Sidebar.css";

const ALL_NAV = [
  { id: "dashboard",   label: "Dashboard",   icon: "⊞", roles: ["admin","hr","manager","employee"] },
  { id: "employees",   label: "Employees",   icon: "👥", roles: ["admin","hr","manager"] },
  { id: "attendance",  label: "Attendance",  icon: "📅", roles: ["admin","hr","manager","employee"] },
  { id: "leave",       label: "Leave",       icon: "🌴", roles: ["admin","hr","manager","employee"] },
  { id: "payroll",     label: "Payroll",     icon: "💰", roles: ["admin","hr","manager","employee"] },
  { id: "recruitment", label: "Recruitment", icon: "🎯", roles: ["admin","hr","manager"] },
  { id: "performance", label: "Performance", icon: "📈", roles: ["admin","hr","manager","employee"] },
];

export default function Sidebar({
  activePage, setActivePage,
  sidebarOpen, setSidebarOpen,
  user, onLogout, isEmployee,
}) {
  const initials = user?.name
    ? user.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase()
    : "HR";

  const roleLabel = {
    admin: "Administrator", hr: "HR Manager",
    manager: "Manager", employee: "Employee",
  };

  const navItems = ALL_NAV.filter(item => item.roles.includes(user?.role || "hr"));

  return (
    <aside className={`sidebar ${sidebarOpen ? "open" : "closed"}`}>
      <div className="sidebar-header">
        <div className="logo">
          <div className="logo-icon">H</div>
          {sidebarOpen && <span className="logo-text">HRFlow</span>}
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          {sidebarOpen && <Notifications />}
          <button className="toggle-btn" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? "‹" : "›"}
          </button>
        </div>
      </div>

      {sidebarOpen && (
        <div className="user-card" style={{ cursor:"pointer" }} onClick={() => setActivePage("profile")} title="View Profile">
          <div className="avatar" style={{ background: "linear-gradient(135deg,#4f8bff,#00d4b4)", color: "white" }}>
            {initials}
          </div>
          <div className="user-info">
            <div className="user-name">{user?.name || "Admin"}</div>
            <div className="user-role">{roleLabel[user?.role] || "HR Manager"}</div>
          </div>
        </div>
      )}

      {sidebarOpen && <div className="nav-section-label">Main Menu</div>}

      <nav className="nav">
        {navItems.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${activePage === item.id ? "active" : ""}`}
            onClick={() => setActivePage(item.id)}
            title={!sidebarOpen ? item.label : ""}
          >
            <span className="nav-icon">{item.icon}</span>
            {sidebarOpen && <span className="nav-label">{item.label}</span>}
            {sidebarOpen && activePage === item.id && <span className="nav-dot" />}
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        {sidebarOpen ? (
          <>
            <button className="nav-item" onClick={() => setActivePage("profile")}>
              <span className="nav-icon">👤</span>
              <span className="nav-label">Profile</span>
            </button>
            <button className="nav-item" onClick={onLogout}>
              <span className="nav-icon">🚪</span>
              <span className="nav-label">Logout</span>
            </button>
          </>
        ) : (
          <>
            <button className="nav-item" title="Profile" onClick={() => setActivePage("profile")}>
              <span className="nav-icon">👤</span>
            </button>
            <button className="nav-item" title="Logout" onClick={onLogout}>
              <span className="nav-icon">🚪</span>
            </button>
          </>
        )}
      </div>
    </aside>
  );
}
