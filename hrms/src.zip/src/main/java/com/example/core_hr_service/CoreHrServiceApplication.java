package com.example.core_hr_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class CoreHrServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(CoreHrServiceApplication.class, args);
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                    .allowedOrigins("http://localhost:3000") // Replace with your frontend URL(s)
                    .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // Explicit methods (better than "*")
                    .allowedHeaders("*")
                    .allowCredentials(true); // Enable if using cookies/auth headers
            }
        };
    }
}