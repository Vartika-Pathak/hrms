package com.example.core_hr_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.List;

@Service
public class EmployeeService {

    private final Path uploadDir = Paths.get("uploads");

    @Autowired
    private EmployeeRepository employeeRepository;

    public EmployeeService() throws IOException {
        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }
    }

    public Employee saveEmployeeWithFiles(
            String name,
            String surname,
            String phone,
            String email,
            String department,
            LocalDate onboardDate,
            MultipartFile profilePhoto,
            MultipartFile cv,
            MultipartFile idDoc,
            MultipartFile contract
    ) {
        Employee employee = new Employee();
        employee.setName(name);
        employee.setSurname(surname);
        employee.setPhone(phone);
        employee.setEmail(email);
        employee.setDepartment(department);
        employee.setOnboardDate(onboardDate);

        if (profilePhoto != null && !profilePhoto.isEmpty()) {
            String photoPath = saveFile(profilePhoto, "profile_" + System.currentTimeMillis());
            employee.setProfilePhotoPath(photoPath);
        }

        if (cv != null && !cv.isEmpty()) {
            String cvPath = saveFile(cv, "cv_" + System.currentTimeMillis());
            employee.setCvPath(cvPath);
        }

        if (idDoc != null && !idDoc.isEmpty()) {
            String idPath = saveFile(idDoc, "id_" + System.currentTimeMillis());
            employee.setIdPath(idPath);
        }

        if (contract != null && !contract.isEmpty()) {
            String contractPath = saveFile(contract, "contract_" + System.currentTimeMillis());
            employee.setContractPath(contractPath);
        }

        return employeeRepository.save(employee);
    }

    private String saveFile(MultipartFile file, String prefix) {
        try {
            String originalFilename = file.getOriginalFilename();
            String extension = "";

            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }

            String fileName = prefix + extension;
            Path filePath = uploadDir.resolve(fileName);

            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            return filePath.toAbsolutePath().toString();
        } catch (IOException e) {
            throw new RuntimeException("Failed to save file: " + e.getMessage());
        }
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    public ResponseEntity<Resource> downloadDocument(Long id, String docType) throws IOException {
        Employee employee = getEmployeeById(id);
        String filePath = getDocumentPath(employee, docType);

        Path path = Paths.get(filePath);
        Resource resource = new UrlResource(path.toUri());

        if (!resource.exists() || !resource.isReadable()) {
            throw new RuntimeException("Could not read file");
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

    private String getDocumentPath(Employee employee, String docType) {
        switch (docType.toLowerCase()) {
            case "cv":
                return employee.getCvPath();
            case "id":
                return employee.getIdPath();
            case "contract":
                return employee.getContractPath();
            case "photo":
                return employee.getProfilePhotoPath();
            default:
                throw new IllegalArgumentException("Invalid document type: " + docType);
        }
    }

    public void deleteEmployee(Long id) {
        Employee employee = getEmployeeById(id);

        try {
            deleteIfExists(employee.getProfilePhotoPath());
            deleteIfExists(employee.getCvPath());
            deleteIfExists(employee.getIdPath());
            deleteIfExists(employee.getContractPath());
        } catch (IOException e) {
            throw new RuntimeException("Failed to delete employee files", e);
        }

        employeeRepository.deleteById(id);
    }

    private void deleteIfExists(String filePath) throws IOException {
        if (filePath != null && !filePath.isBlank()) {
            Files.deleteIfExists(Paths.get(filePath));
        }
    }
}
