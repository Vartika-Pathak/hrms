package com.example.core_hr_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreHrServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
